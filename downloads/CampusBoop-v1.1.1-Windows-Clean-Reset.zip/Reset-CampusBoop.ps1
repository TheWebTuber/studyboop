$ErrorActionPreference = 'Stop'
$host.UI.RawUI.WindowTitle = 'CampusBoop Clean Reset'

Write-Host ''
Write-Host 'CampusBoop Clean Reset' -ForegroundColor Cyan
Write-Host '----------------------'
Write-Host 'This removes CampusBoop settings, reminder state, saved login,'
Write-Host 'local WebView2 data, old test profiles, and CampusBoop startup entries.'
Write-Host 'It does NOT delete the CampusBoop program folder.'
Write-Host ''
$answer = Read-Host 'Type RESET to continue'
if ($answer -cne 'RESET') {
    Write-Host 'Cancelled. Nothing was changed.' -ForegroundColor Yellow
    exit 0
}

Write-Host ''
Write-Host 'Stopping CampusBoop...' -ForegroundColor DarkCyan
try {
    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
        Where-Object {
            ($_.Name -match '^powershell(\.exe)?$' -and $_.CommandLine -and $_.CommandLine -like '*SchoolCheckIn.ps1*') -or
            ($_.Name -ieq 'SchoolLogin.exe')
        } |
        ForEach-Object {
            try { Invoke-CimMethod -InputObject $_ -MethodName Terminate -ErrorAction SilentlyContinue | Out-Null } catch { }
        }
} catch { }
Start-Sleep -Milliseconds 600

$targets = @((Join-Path $env:LOCALAPPDATA 'SchoolCheckInHelper'))
try {
    $targets += @(Get-ChildItem -LiteralPath $env:LOCALAPPDATA -Directory -Filter 'CampusBoop-Test-*' -ErrorAction SilentlyContinue | ForEach-Object FullName)
} catch { }

foreach ($target in ($targets | Select-Object -Unique)) {
    if ($target -and (Test-Path -LiteralPath $target)) {
        Write-Host ('Removing ' + $target)
        Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction Stop
    }
}

$startup = [Environment]::GetFolderPath('Startup')
if ($startup -and (Test-Path -LiteralPath $startup)) {
    Get-ChildItem -LiteralPath $startup -Filter 'CampusBoop*.lnk' -File -ErrorAction SilentlyContinue | ForEach-Object {
        Write-Host ('Removing startup shortcut ' + $_.Name)
        Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue
    }
}

# Harmless future-proof cleanup if a CampusBoop Run entry exists.
try {
    $runKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
    if (Get-ItemProperty -Path $runKey -Name 'CampusBoop' -ErrorAction SilentlyContinue) {
        Remove-ItemProperty -Path $runKey -Name 'CampusBoop' -ErrorAction SilentlyContinue
        Write-Host 'Removed CampusBoop Windows Run entry.'
    }
} catch { }

Write-Host ''
Write-Host 'Reset complete.' -ForegroundColor Green
Write-Host 'For the closest possible fresh-install test, extract a NEW copy of the CampusBoop New-User ZIP and run CampusBoop.exe.'
Write-Host 'You should receive the Welcome / first-run setup again.'
Write-Host ''
Read-Host 'Press Enter to close' | Out-Null
