CampusBoop v1.1.1 - Clean Reset
================================

Use this when you want to test CampusBoop exactly like a new Windows user.

1. Exit CampusBoop if it is open.
2. Double-click RESET-CAMPUSBOOP.cmd.
3. Type RESET.
4. After it says Reset complete, extract a fresh copy of the separate CampusBoop New-User ZIP.
5. Run CampusBoop.exe and complete the Welcome setup.

The reset removes:
- %LOCALAPPDATA%\SchoolCheckInHelper
  - settings.json
  - state.json
  - encrypted login.bin
  - local WebView2 BrowserProfile
- old %LOCALAPPDATA%\CampusBoop-Test-* profiles
- CampusBoop startup shortcuts
- a CampusBoop HKCU Run entry if one exists

It does NOT delete the program folder and does not touch your HvA/UvA account, school files, or normal browser profile.
