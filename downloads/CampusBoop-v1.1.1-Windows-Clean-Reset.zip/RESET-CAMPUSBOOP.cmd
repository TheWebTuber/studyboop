@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Reset-CampusBoop.ps1"
endlocal
