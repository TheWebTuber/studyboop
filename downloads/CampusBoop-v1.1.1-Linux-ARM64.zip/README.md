# CampusBoop v1.1.1 — Linux ARM64

CampusBoop is an independent student-made helper for HvA/UvA workflows.

Recommended install:

```bash
curl -fsSL https://campusboop.creatorpromote.com/install-campusboop.sh | bash
```

Manual run from this ZIP:

```bash
chmod +x CampusBoop
./CampusBoop
```

CampusBoop stores its Linux settings in `~/.config/campusboop` (or `$XDG_CONFIG_HOME/campusboop`). School authentication opens in your normal browser; CampusBoop does not store your HvA/UvA password on Linux.

Instructions: https://campusboop.creatorpromote.com/#instructions
