# CampusBoop v1.1 source

CampusBoop is an independent student-made study helper. It is not an official HvA or UvA application.

This source package contains:

- `Windows/` — Windows PowerShell/WinForms app, launcher source, trusted WebView2 login helper source and bundled WebView2 runtime libraries used by the release.
- `Linux/` — Go source and embedded local browser UI used for both x64 and ARM64 builds.
- `Website/` — the public one-page website and install scripts.

The public release website is https://campusboop.creatorpromote.com/.
