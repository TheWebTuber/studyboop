# CampusBoop v1.1 — Linux

CampusBoop is an independent student-made helper for HvA/UvA study workflows. It is not an official HvA or UvA application.

The Linux build is a self-contained native binary. The same source is built for x64 and ARM64.

## First start

Run:

```bash
campusboop
```

CampusBoop opens a local-only interface on `127.0.0.1`. On first start you can choose HvA/UvA, startup behavior, the startup reminder, smart VS Code check-in detection, and the reminder delay.

## Student tools

The bottom of the CampusBoop home screen contains editable **Print**, **Top up**, and **Library** buttons. HvA/UvA presets are included, and all names/URLs can be replaced in Settings.

Linux opens school pages in your normal browser and does not store a school password.

## Commands

```bash
campusboop
campusboop --background
campusboop --autostart-on
campusboop --autostart-off
campusboop --help
campusboop --uninstall
campusboop --purge
```

`--uninstall` keeps local settings. `--purge` removes the app and its local CampusBoop settings.

## Desktop detection

When `xdotool` is available on X11, CampusBoop can check whether VS Code is in the foreground. On Wayland or systems without `xdotool`, it falls back to checking whether VS Code is running.
