package main

import (
	"embed"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"
)

const version = "1.1"

//go:embed ui.html
var content embed.FS

type DayRule struct {
	Day     string `json:"day"`
	Enabled bool   `json:"enabled"`
	Start   string `json:"start"`
	End     string `json:"end"`
}

type Config struct {
	LoginURL               string    `json:"loginUrl"`
	CheckinURL             string    `json:"checkinUrl"`
	Option1Name            string    `json:"option1Name"`
	Option1URL             string    `json:"option1Url"`
	Option2Name            string    `json:"option2Name"`
	Option2URL             string    `json:"option2Url"`
	Tool1Name              string    `json:"tool1Name"`
	Tool1URL               string    `json:"tool1Url"`
	Tool2Name              string    `json:"tool2Name"`
	Tool2URL               string    `json:"tool2Url"`
	Tool3Name              string    `json:"tool3Name"`
	Tool3URL               string    `json:"tool3Url"`
	SchoolProvider         string    `json:"schoolProvider"`
	CooldownMinutes        int       `json:"cooldownMinutes"`
	ReminderMinutes        int       `json:"reminderMinutes"`
	BackgroundEnabled      bool      `json:"backgroundEnabled"`
	SmartReminderEnabled   bool      `json:"smartReminderEnabled"`
	StartupReminderEnabled bool      `json:"startupReminderEnabled"`
	StartupDelayMinutes    int       `json:"startupDelayMinutes"`
	OnboardingComplete     bool      `json:"onboardingComplete"`
	ScheduleEnabled        bool      `json:"scheduleEnabled"`
	WeeklySchedule         []DayRule `json:"weeklySchedule"`
}

type State struct {
	DoneDate     string `json:"doneDate"`
	CheckoutDate string `json:"checkoutDate"`
}

type Runtime struct {
	Paused               bool      `json:"paused"`
	BreakUntil           time.Time `json:"breakUntil"`
	NextReminder         time.Time `json:"nextReminder"`
	NextCommitReminder   time.Time `json:"nextCommitReminder"`
	HadCodeWindow        bool      `json:"hadCodeWindow"`
	StartupReminderAt    time.Time `json:"startupReminderAt"`
	StartupReminderShown bool      `json:"startupReminderShown"`
}

type App struct {
	mu         sync.Mutex
	cfg        Config
	state      State
	rt         Runtime
	dataDir    string
	configPath string
	statePath  string
	portPath   string
	exePath    string
	server     *http.Server
	listener   net.Listener
	done       chan struct{}
}

func defaultSchedule() []DayRule {
	days := []string{"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"}
	out := make([]DayRule, 0, 7)
	for _, d := range days {
		out = append(out, DayRule{Day: d, Enabled: false, Start: "09:00", End: "17:00"})
	}
	return out
}

func schoolDefaults(school string) (string, string, string, string, string, string) {
	if school == "uva" {
		return "Print", "https://uva.mycampusprint.nl/Login/Login", "Top up", "https://uva-hva.mynetpay.nl/Auth/Login", "Library", "https://lib.uva.nl"
	}
	return "Print", "https://hva.mycampusprint.nl/Login/Login", "Top up", "https://uva-hva.mynetpay.nl/Auth/Login", "Library", "https://lib.hva.nl"
}

func applySchoolDefaults(c *Config, school string) {
	if school != "uva" {
		school = "hva"
	}
	c.SchoolProvider = school
	c.Tool1Name, c.Tool1URL, c.Tool2Name, c.Tool2URL, c.Tool3Name, c.Tool3URL = schoolDefaults(school)
}

func defaultConfig() Config {
	c := Config{
		LoginURL:               "https://dlo.mijnhva.nl/d2l/home",
		CheckinURL:             "https://dlo.mijnhva.nl/d2l/le/lessons/762152/topics/2936746",
		Option1Name:            "Check-in 1",
		Option2Name:            "Check-in 2",
		SchoolProvider:         "hva",
		CooldownMinutes:        60,
		ReminderMinutes:        45,
		BackgroundEnabled:      true,
		SmartReminderEnabled:   true,
		StartupReminderEnabled: true,
		StartupDelayMinutes:    2,
		OnboardingComplete:     false,
		ScheduleEnabled:        false,
		WeeklySchedule:         defaultSchedule(),
	}
	applySchoolDefaults(&c, "hva")
	return c
}

func configHome() (string, error) {
	if x := os.Getenv("XDG_CONFIG_HOME"); x != "" {
		return filepath.Join(x, "campusboop"), nil
	}
	h, err := os.UserHomeDir()
	if err != nil {
		return "", err
	}
	return filepath.Join(h, ".config", "campusboop"), nil
}

func newApp() (*App, error) {
	d, err := configHome()
	if err != nil {
		return nil, err
	}
	if err := os.MkdirAll(d, 0700); err != nil {
		return nil, err
	}
	exe, _ := os.Executable()
	exe, _ = filepath.Abs(exe)
	a := &App{dataDir: d, configPath: filepath.Join(d, "settings.json"), statePath: filepath.Join(d, "state.json"), portPath: filepath.Join(d, "port"), exePath: exe, done: make(chan struct{})}
	a.cfg = defaultConfig()
	a.state = State{}
	_ = readJSON(a.configPath, &a.cfg)
	_ = readJSON(a.statePath, &a.state)
	if len(a.cfg.WeeklySchedule) != 7 {
		a.cfg.WeeklySchedule = defaultSchedule()
	}
	if a.cfg.SchoolProvider != "uva" {
		a.cfg.SchoolProvider = "hva"
	}
	if a.cfg.StartupDelayMinutes < 1 || a.cfg.StartupDelayMinutes > 60 {
		a.cfg.StartupDelayMinutes = 2
	}
	if strings.TrimSpace(a.cfg.Tool1Name) == "" || strings.TrimSpace(a.cfg.Tool1URL) == "" || strings.TrimSpace(a.cfg.Tool2Name) == "" || strings.TrimSpace(a.cfg.Tool2URL) == "" || strings.TrimSpace(a.cfg.Tool3Name) == "" || strings.TrimSpace(a.cfg.Tool3URL) == "" {
		applySchoolDefaults(&a.cfg, a.cfg.SchoolProvider)
	}
	now := time.Now()
	a.rt.NextReminder = now
	a.rt.NextCommitReminder = now.Add(time.Duration(a.cfg.ReminderMinutes) * time.Minute)
	return a, nil
}

func readJSON(path string, v any) error {
	b, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	return json.Unmarshal(b, v)
}
func writeJSON(path string, v any) error {
	b, err := json.MarshalIndent(v, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, b, 0600)
}
func (a *App) saveConfig() { _ = writeJSON(a.configPath, a.cfg) }
func (a *App) saveState()  { _ = writeJSON(a.statePath, a.state) }

func (a *App) uiURL(mode string) string {
	port := ""
	if a.listener != nil {
		_, p, _ := net.SplitHostPort(a.listener.Addr().String())
		port = p
	}
	u := "http://127.0.0.1:" + port + "/"
	if mode != "" {
		u += "?mode=" + mode
	}
	return u
}

func openBrowser(url string) error { return exec.Command("xdg-open", url).Start() }
func notify(title, body string) {
	if _, err := exec.LookPath("notify-send"); err == nil {
		_ = exec.Command("notify-send", "--app-name=CampusBoop", title, body).Start()
	}
}

func (a *App) openExternal(url string) error {
	if !strings.HasPrefix(strings.ToLower(strings.TrimSpace(url)), "https://") {
		return errors.New("only HTTPS links are allowed")
	}
	return openBrowser(url)
}

func (a *App) autostartPath() string {
	return filepath.Join(filepath.Dir(a.dataDir), "autostart", "CampusBoop.desktop")
}
func (a *App) setAutostart(on bool) error {
	p := a.autostartPath()
	if !on {
		if err := os.Remove(p); err != nil && !os.IsNotExist(err) {
			return err
		}
		return nil
	}
	if err := os.MkdirAll(filepath.Dir(p), 0755); err != nil {
		return err
	}
	text := fmt.Sprintf("[Desktop Entry]\nType=Application\nName=CampusBoop\nComment=Student check-in, commit and break reminder\nExec=%s --background\nTerminal=false\nX-GNOME-Autostart-enabled=true\n", shellEscapeDesktop(a.exePath))
	return os.WriteFile(p, []byte(text), 0644)
}
func shellEscapeDesktop(s string) string {
	if strings.ContainsAny(s, " \t\"") {
		return "\"" + strings.ReplaceAll(s, "\"", "\\\"") + "\""
	}
	return s
}
func (a *App) autostartEnabled() bool { _, err := os.Stat(a.autostartPath()); return err == nil }

func (a *App) statusPayload() map[string]any {
	a.mu.Lock()
	defer a.mu.Unlock()
	now := time.Now()
	today := now.Format("2006-01-02")
	return map[string]any{
		"version": version, "config": a.cfg, "state": a.state, "paused": a.rt.Paused,
		"breakUntil": a.rt.BreakUntil, "autostart": a.autostartEnabled(),
		"checkedInToday": a.state.DoneDate == today, "checkedOutToday": a.state.CheckoutDate == today,
	}
}

func (a *App) handleAPI(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	if r.Method == http.MethodGet {
		_ = json.NewEncoder(w).Encode(a.statusPayload())
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", 405)
		return
	}
	var req map[string]any
	if err := json.NewDecoder(io.LimitReader(r.Body, 1<<20)).Decode(&req); err != nil {
		http.Error(w, "bad request", 400)
		return
	}
	action, _ := req["action"].(string)
	var err error
	a.mu.Lock()
	now := time.Now()
	today := now.Format("2006-01-02")
	switch action {
	case "checked-in":
		a.state.DoneDate = today
		a.state.CheckoutDate = ""
		a.saveState()
	case "checked-out":
		a.state.CheckoutDate = today
		a.saveState()
	case "remind-15":
		a.rt.NextReminder = now.Add(15 * time.Minute)
	case "break-10":
		a.rt.BreakUntil = now.Add(10 * time.Minute)
		a.rt.NextCommitReminder = a.rt.BreakUntil.Add(time.Duration(a.cfg.ReminderMinutes) * time.Minute)
	case "resume":
		a.rt.BreakUntil = time.Time{}
		a.rt.NextCommitReminder = now.Add(time.Duration(a.cfg.ReminderMinutes) * time.Minute)
	case "toggle-pause":
		a.rt.Paused = !a.rt.Paused
	case "enable-today":
		a.state = State{}
		a.rt.NextReminder = now
		a.rt.NextCommitReminder = now.Add(time.Duration(a.cfg.ReminderMinutes) * time.Minute)
		a.saveState()
	case "open-login":
		err = a.openExternal(a.cfg.LoginURL)
	case "open-option1":
		u := a.cfg.Option1URL
		if strings.TrimSpace(u) == "" {
			u = a.cfg.CheckinURL
		}
		err = a.openExternal(u)
	case "open-option2":
		u := a.cfg.Option2URL
		if strings.TrimSpace(u) == "" {
			u = a.cfg.CheckinURL
		}
		err = a.openExternal(u)
	case "open-tool1":
		err = a.openExternal(a.cfg.Tool1URL)
	case "open-tool2":
		err = a.openExternal(a.cfg.Tool2URL)
	case "open-tool3":
		err = a.openExternal(a.cfg.Tool3URL)
	case "complete-onboarding":
		school, _ := req["schoolProvider"].(string)
		if school != "uva" {
			school = "hva"
		}
		applySchoolDefaults(&a.cfg, school)
		if v, ok := req["smartReminderEnabled"].(bool); ok {
			a.cfg.SmartReminderEnabled = v
		}
		if v, ok := req["startupReminderEnabled"].(bool); ok {
			a.cfg.StartupReminderEnabled = v
		}
		if v, ok := req["startupDelayMinutes"].(float64); ok && int(v) >= 1 && int(v) <= 60 {
			a.cfg.StartupDelayMinutes = int(v)
		}
		if v, ok := req["backgroundEnabled"].(bool); ok {
			a.cfg.BackgroundEnabled = v
		}
		a.cfg.OnboardingComplete = true
		if v, ok := req["autostart"].(bool); ok {
			err = a.setAutostart(v)
		}
		a.saveConfig()
	case "save-settings":
		raw, ok := req["config"]
		if !ok {
			err = errors.New("missing config")
			break
		}
		b, _ := json.Marshal(raw)
		c := a.cfg
		if e := json.Unmarshal(b, &c); e != nil {
			err = e
			break
		}
		if c.CooldownMinutes < 1 || c.CooldownMinutes > 1440 || c.ReminderMinutes < 1 || c.ReminderMinutes > 1440 {
			err = errors.New("reminder intervals must be 1-1440 minutes")
			break
		}
		if c.StartupDelayMinutes < 1 || c.StartupDelayMinutes > 60 {
			err = errors.New("startup delay must be 1-60 minutes")
			break
		}
		if c.SchoolProvider != "uva" {
			c.SchoolProvider = "hva"
		}
		if !httpsOrBlank(c.LoginURL, false) || !httpsOrBlank(c.CheckinURL, false) || !httpsOrBlank(c.Option1URL, true) || !httpsOrBlank(c.Option2URL, true) || !httpsOrBlank(c.Tool1URL, false) || !httpsOrBlank(c.Tool2URL, false) || !httpsOrBlank(c.Tool3URL, false) {
			err = errors.New("all configured links must use HTTPS")
			break
		}
		if strings.TrimSpace(c.Tool1Name) == "" || strings.TrimSpace(c.Tool2Name) == "" || strings.TrimSpace(c.Tool3Name) == "" {
			err = errors.New("student tool names cannot be empty")
			break
		}
		if len(c.WeeklySchedule) != 7 {
			c.WeeklySchedule = defaultSchedule()
		}
		c.OnboardingComplete = true
		a.cfg = c
		a.rt.NextCommitReminder = now.Add(time.Duration(c.ReminderMinutes) * time.Minute)
		a.saveConfig()
	case "apply-school-defaults":
		school, _ := req["schoolProvider"].(string)
		applySchoolDefaults(&a.cfg, school)
		a.saveConfig()
	case "autostart-on":
		err = a.setAutostart(true)
	case "autostart-off":
		err = a.setAutostart(false)
	case "exit":
		go func() {
			time.Sleep(150 * time.Millisecond)
			_ = a.server.Close()
			select {
			case <-a.done:
			default:
				close(a.done)
			}
		}()
	default:
		err = errors.New("unknown action")
	}
	a.mu.Unlock()
	if err != nil {
		w.WriteHeader(400)
		_ = json.NewEncoder(w).Encode(map[string]any{"ok": false, "error": err.Error()})
		return
	}
	_ = json.NewEncoder(w).Encode(map[string]any{"ok": true})
}

func httpsOrBlank(s string, blank bool) bool {
	s = strings.TrimSpace(strings.ToLower(s))
	if s == "" {
		return blank
	}
	return strings.HasPrefix(s, "https://")
}

func (a *App) allowedNow(t time.Time) bool {
	if !a.cfg.ScheduleEnabled {
		return true
	}
	n := t.Hour()*60 + t.Minute()
	day := t.Weekday().String()
	prev := t.AddDate(0, 0, -1).Weekday().String()
	for _, r := range a.cfg.WeeklySchedule {
		if !r.Enabled {
			continue
		}
		sm, ok1 := clockMinutes(r.Start)
		em, ok2 := clockMinutes(r.End)
		if !ok1 || !ok2 || sm == em {
			continue
		}
		if r.Day == day {
			if sm < em && n >= sm && n < em {
				return true
			}
			if sm > em && n >= sm {
				return true
			}
		}
		if r.Day == prev && sm > em && n < em {
			return true
		}
	}
	return false
}
func clockMinutes(s string) (int, bool) {
	p := strings.Split(s, ":")
	if len(p) != 2 {
		return 0, false
	}
	h, e1 := strconv.Atoi(p[0])
	m, e2 := strconv.Atoi(p[1])
	if e1 != nil || e2 != nil || h < 0 || h > 23 || m < 0 || m > 59 {
		return 0, false
	}
	return h*60 + m, true
}

func codeRunning() bool {
	entries, err := os.ReadDir("/proc")
	if err != nil {
		return false
	}
	for _, e := range entries {
		if !e.IsDir() {
			continue
		}
		if _, err := strconv.Atoi(e.Name()); err != nil {
			continue
		}
		b, err := os.ReadFile(filepath.Join("/proc", e.Name(), "comm"))
		if err != nil {
			continue
		}
		n := strings.TrimSpace(strings.ToLower(string(b)))
		if n == "code" || n == "code-insiders" {
			return true
		}
	}
	return false
}
func codeForeground() bool {
	if _, err := exec.LookPath("xdotool"); err != nil {
		return codeRunning()
	}
	out, err := exec.Command("sh", "-c", "xdotool getactivewindow getwindowpid 2>/dev/null").Output()
	if err != nil {
		return codeRunning()
	}
	pid := strings.TrimSpace(string(out))
	if pid == "" {
		return codeRunning()
	}
	b, err := os.ReadFile(filepath.Join("/proc", pid, "comm"))
	if err != nil {
		return codeRunning()
	}
	n := strings.TrimSpace(strings.ToLower(string(b)))
	return n == "code" || n == "code-insiders"
}

func (a *App) reminderLoop() {
	tick := time.NewTicker(2 * time.Second)
	defer tick.Stop()
	for range tick.C {
		a.mu.Lock()
		now := time.Now()
		today := now.Format("2006-01-02")
		hasCode := codeRunning()
		justClosed := a.rt.HadCodeWindow && !hasCode
		a.rt.HadCodeWindow = hasCode
		mode := ""
		title := ""
		body := ""

		if !a.rt.StartupReminderShown && a.cfg.StartupReminderEnabled && !a.rt.StartupReminderAt.IsZero() && !now.Before(a.rt.StartupReminderAt) && a.allowedNow(now) {
			a.rt.StartupReminderShown = true
			if !a.rt.Paused && a.state.DoneDate != today && a.state.CheckoutDate != today {
				mode = "startup"
				title = "Boop — don't forget to check in"
				body = "Going to school today? CampusBoop is ready when you need it."
			}
		}

		if mode == "" && (a.rt.Paused || a.state.CheckoutDate == today || (!a.rt.BreakUntil.IsZero() && now.Before(a.rt.BreakUntil)) || !a.allowedNow(now)) {
			a.mu.Unlock()
			continue
		}
		if mode == "" && justClosed {
			mode = "checkout"
			title = "Boop — finished for today?"
			body = "Remember to commit/push and check out if you're done."
		}
		if mode == "" && hasCode && codeForeground() {
			if !now.Before(a.rt.NextCommitReminder) {
				a.rt.NextCommitReminder = now.Add(time.Duration(a.cfg.ReminderMinutes) * time.Minute)
				mode = "commit"
				title = "Boop — save your work"
				body = "Commit or push your work, then take a quick break if you need one."
			} else if a.cfg.SmartReminderEnabled && a.state.DoneDate != today && !now.Before(a.rt.NextReminder) {
				a.rt.NextReminder = now.Add(time.Duration(a.cfg.CooldownMinutes) * time.Minute)
				mode = "checkin"
				title = "Boop — school check-in"
				body = "Open CampusBoop to log in and complete your school check-in."
			}
		}
		a.mu.Unlock()
		if mode != "" {
			notify(title, body)
			_ = openBrowser(a.uiURL(mode))
		}
	}
}

func acquireLock(path string) (*os.File, error) {
	f, err := os.OpenFile(path, os.O_CREATE|os.O_RDWR, 0600)
	if err != nil {
		return nil, err
	}
	if err := syscall.Flock(int(f.Fd()), syscall.LOCK_EX|syscall.LOCK_NB); err != nil {
		f.Close()
		return nil, err
	}
	return f, nil
}

func openExisting(dataDir string) bool {
	b, err := os.ReadFile(filepath.Join(dataDir, "port"))
	if err != nil {
		return false
	}
	p := strings.TrimSpace(string(b))
	if p == "" {
		return false
	}
	_ = openBrowser("http://127.0.0.1:" + p + "/")
	return true
}

func printHelp() {
	fmt.Println("CampusBoop v" + version)
	fmt.Println("  campusboop                 Open CampusBoop")
	fmt.Println("  campusboop --background    Run quietly in the background")
	fmt.Println("  campusboop --autostart-on  Start CampusBoop when you sign in")
	fmt.Println("  campusboop --autostart-off Disable sign-in startup")
	fmt.Println("  campusboop --help          Show this help")
	fmt.Println("  campusboop --version       Show version")
	fmt.Println("  campusboop --uninstall     Remove CampusBoop (keep settings)")
	fmt.Println("  campusboop --purge         Remove CampusBoop and local settings")
	fmt.Println("Instructions: https://campusboop.creatorpromote.com/#instructions")
}

func main() {
	args := os.Args[1:]
	background := false
	for _, a := range args {
		switch a {
		case "--help", "-h":
			printHelp()
			return
		case "--version":
			fmt.Println(version)
			return
		case "--background":
			background = true
		}
	}
	app, err := newApp()
	if err != nil {
		fmt.Fprintln(os.Stderr, "CampusBoop:", err)
		os.Exit(1)
	}
	for _, a := range args {
		switch a {
		case "--autostart-on":
			if err := app.setAutostart(true); err != nil {
				fmt.Fprintln(os.Stderr, err)
				os.Exit(1)
			}
			fmt.Println("CampusBoop startup enabled.")
			return
		case "--autostart-off":
			if err := app.setAutostart(false); err != nil {
				fmt.Fprintln(os.Stderr, err)
				os.Exit(1)
			}
			fmt.Println("CampusBoop startup disabled.")
			return
		}
	}
	if background && app.cfg.StartupReminderEnabled {
		app.rt.StartupReminderAt = time.Now().Add(time.Duration(app.cfg.StartupDelayMinutes) * time.Minute)
		app.rt.StartupReminderShown = false
	} else {
		app.rt.StartupReminderShown = true
	}

	lock, err := acquireLock(filepath.Join(app.dataDir, "instance.lock"))
	if err != nil {
		if !background && openExisting(app.dataDir) {
			return
		}
		return
	}
	defer lock.Close()
	mux := http.NewServeMux()
	mux.HandleFunc("/api/state", app.handleAPI)
	mux.HandleFunc("/api/action", app.handleAPI)
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		b, err := content.ReadFile("ui.html")
		if err != nil {
			http.Error(w, "UI missing", 500)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Cache-Control", "no-store")
		_, _ = w.Write(b)
	})
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	app.listener = ln
	_, port, _ := net.SplitHostPort(ln.Addr().String())
	_ = os.WriteFile(app.portPath, []byte(port), 0600)
	defer os.Remove(app.portPath)
	app.server = &http.Server{Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	go app.reminderLoop()
	go func() { _ = app.server.Serve(ln) }()
	if !background || !app.cfg.BackgroundEnabled {
		_ = openBrowser(app.uiURL(""))
	}
	<-app.done
}
