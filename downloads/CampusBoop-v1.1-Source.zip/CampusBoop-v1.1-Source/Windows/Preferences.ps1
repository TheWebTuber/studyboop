Add-Type -AssemblyName System.Security

function New-WeekSchedule {
    @('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') | ForEach-Object {
        [pscustomobject]@{ day = $_; enabled = ($_ -notin @('Saturday','Sunday')); start = '09:00'; end = '17:00' }
    }
}

function Get-SchoolDefaults([string]$school) {
    if ($school -eq 'uva') {
        return [pscustomobject]@{
            schoolProvider = 'uva'; loginProvider = 'login.uva.nl'
            tool1Name = 'Print';   tool1Url = 'https://uva.mycampusprint.nl/Login/Login'
            tool2Name = 'Top up';  tool2Url = 'https://uva-hva.mynetpay.nl/Auth/Login'
            tool3Name = 'Library'; tool3Url = 'https://lib.uva.nl'
        }
    }
    return [pscustomobject]@{
        schoolProvider = 'hva'; loginProvider = 'login.hva.nl'
        tool1Name = 'Print';   tool1Url = 'https://hva.mycampusprint.nl/Login/Login'
        tool2Name = 'Top up';  tool2Url = 'https://uva-hva.mynetpay.nl/Auth/Login'
        tool3Name = 'Library'; tool3Url = 'https://lib.hva.nl'
    }
}

function Apply-StudentToolDefaults([string]$school) {
    $d = Get-SchoolDefaults $school
    $script:config.schoolProvider = $d.schoolProvider
    $script:config.loginProvider = $d.loginProvider
    $script:config.tool1Name = $d.tool1Name; $script:config.tool1Url = $d.tool1Url
    $script:config.tool2Name = $d.tool2Name; $script:config.tool2Url = $d.tool2Url
    $script:config.tool3Name = $d.tool3Name; $script:config.tool3Url = $d.tool3Url
}

function Test-AlarmTime([datetime]$now) {
    if (-not $script:config.scheduleEnabled) { return $true }
    $today = $now.DayOfWeek.ToString(); $previous = $now.AddDays(-1).DayOfWeek.ToString()
    $minute = $now.Hour * 60 + $now.Minute
    foreach ($rule in $script:config.weeklySchedule) {
        if (-not $rule.enabled) { continue }
        $startTime = [datetime]::MinValue; $endTime = [datetime]::MinValue
        if (-not [datetime]::TryParseExact([string]$rule.start,'HH:mm',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$startTime)) { continue }
        if (-not [datetime]::TryParseExact([string]$rule.end,'HH:mm',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$endTime)) { continue }
        $startMinute = $startTime.Hour * 60 + $startTime.Minute; $endMinute = $endTime.Hour * 60 + $endTime.Minute
        if ($startMinute -lt $endMinute -and $rule.day -eq $today -and $minute -ge $startMinute -and $minute -lt $endMinute) { return $true }
        if ($startMinute -gt $endMinute -and (($rule.day -eq $today -and $minute -ge $startMinute) -or ($rule.day -eq $previous -and $minute -lt $endMinute))) { return $true }
    }
    return $false
}

function Get-LoginInfo {
    $path = Join-Path $script:dataDir 'login.bin'
    if (-not (Test-Path -LiteralPath $path)) { return $null }
    try {
        $bytes = [Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes($path),$null,[Security.Cryptography.DataProtectionScope]::CurrentUser)
        $value = [Text.Encoding]::UTF8.GetString($bytes) | ConvertFrom-Json
        [Array]::Clear($bytes,0,$bytes.Length)
        return $value
    } catch {
        [Windows.Forms.MessageBox]::Show('Saved login could not be unlocked. Enter it again or clear it in Settings.','CampusBoop') | Out-Null
        return $null
    }
}

function Save-LoginInfo([string]$id,[string]$password) {
    $path = Join-Path $script:dataDir 'login.bin'
    if ($id -eq '' -and $password -eq '') { if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path }; return }
    $bytes = [Text.Encoding]::UTF8.GetBytes((@{id=$id;password=$password} | ConvertTo-Json -Compress))
    try {
        $protected = [Security.Cryptography.ProtectedData]::Protect($bytes,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser)
        [IO.File]::WriteAllBytes($path,$protected)
    } finally { [Array]::Clear($bytes,0,$bytes.Length) }
}

function Show-Settings {
    $f = New-Object Windows.Forms.Form
    $f.Text = 'CampusBoop settings'; $f.ClientSize = New-Object Drawing.Size(720,590)
    $f.StartPosition = 'CenterScreen'; $f.FormBorderStyle = 'FixedDialog'; $f.MaximizeBox = $false

    $tabs = New-Object Windows.Forms.TabControl
    $tabs.Location = New-Object Drawing.Point(16,12); $tabs.Size = New-Object Drawing.Size(688,485)
    $links = New-Object Windows.Forms.TabPage; $links.Text = 'School links'
    $tools = New-Object Windows.Forms.TabPage; $tools.Text = 'Student tools'
    $login = New-Object Windows.Forms.TabPage; $login.Text = 'Personal login'
    $schedule = New-Object Windows.Forms.TabPage; $schedule.Text = 'Weekly reminders'
    $behavior = New-Object Windows.Forms.TabPage; $behavior.Text = 'Boop / startup'
    $tabs.TabPages.AddRange(@($links,$tools,$login,$schedule,$behavior)); $f.Controls.Add($tabs)
    $tabs.Anchor = 'Top,Bottom,Left,Right'

    # School links
    $fields = @(
        @('loginUrl','School login URL'),
        @('checkinUrl','Shared check-in URL'),
        @('option1Name','First option name'),
        @('option1Url','First option URL (optional)'),
        @('option2Name','Second option name'),
        @('option2Url','Second option URL (optional)'),
        @('cooldownMinutes','Check-in interval (minutes)')
    )
    $boxes = @{}; $y = 20
    foreach ($field in $fields) {
        $label = New-Object Windows.Forms.Label; $label.Text = $field[1]
        $label.Location = New-Object Drawing.Point(12,$y); $label.Size = New-Object Drawing.Size(205,22); $links.Controls.Add($label)
        $box = New-Object Windows.Forms.TextBox; $box.Text = [string]$script:config.($field[0])
        $box.Location = New-Object Drawing.Point(222,$y); $box.Size = New-Object Drawing.Size(435,24)
        $links.Controls.Add($box); $boxes[$field[0]] = $box; $y += 48
    }

    # Student tools
    $toolBoxes = @{}; $y = 20
    foreach ($field in @(
        @('tool1Name','Tool 1 name'),@('tool1Url','Tool 1 URL'),
        @('tool2Name','Tool 2 name'),@('tool2Url','Tool 2 URL'),
        @('tool3Name','Tool 3 name'),@('tool3Url','Tool 3 URL')
    )) {
        $label = New-Object Windows.Forms.Label; $label.Text = $field[1]
        $label.Location = New-Object Drawing.Point(12,$y); $label.Size = New-Object Drawing.Size(165,22); $tools.Controls.Add($label)
        $box = New-Object Windows.Forms.TextBox; $box.Text = [string]$script:config.($field[0])
        $box.Location = New-Object Drawing.Point(182,$y); $box.Size = New-Object Drawing.Size(475,24)
        $tools.Controls.Add($box); $toolBoxes[$field[0]] = $box; $y += 45
    }
    $toolNote = New-Object Windows.Forms.Label
    $toolNote.Text = 'These buttons stay at the bottom of the main CampusBoop window. Rename them or replace the URLs with anything you prefer.'
    $toolNote.Location = New-Object Drawing.Point(12,305); $toolNote.Size = New-Object Drawing.Size(645,48); $tools.Controls.Add($toolNote)
    $hvaDefaults = New-Object Windows.Forms.Button; $hvaDefaults.Text = 'Use HvA defaults'; $hvaDefaults.Location = New-Object Drawing.Point(182,368); $hvaDefaults.Size = New-Object Drawing.Size(180,34)
    $uvaDefaults = New-Object Windows.Forms.Button; $uvaDefaults.Text = 'Use UvA defaults'; $uvaDefaults.Location = New-Object Drawing.Point(377,368); $uvaDefaults.Size = New-Object Drawing.Size(180,34)
    $setToolBoxes = {
        param([string]$school)
        $d = Get-SchoolDefaults $school
        foreach ($k in @('tool1Name','tool1Url','tool2Name','tool2Url','tool3Name','tool3Url')) { $toolBoxes[$k].Text = [string]$d.$k }
    }
    $hvaDefaults.Add_Click({ & $setToolBoxes 'hva' }); $uvaDefaults.Add_Click({ & $setToolBoxes 'uva' })
    $tools.Controls.Add($hvaDefaults); $tools.Controls.Add($uvaDefaults)

    # Personal login / trusted school
    $autoLogin = New-Object Windows.Forms.CheckBox
    $autoLogin.Text = 'Fill and submit my saved school login automatically on the trusted HvA/UvA ADFS page'
    $autoLogin.Location = New-Object Drawing.Point(16,18); $autoLogin.Size = New-Object Drawing.Size(640,34)
    $autoLogin.Checked = [bool]$script:config.autoLoginEnabled; $login.Controls.Add($autoLogin)
    $loginBoxes = @{}; $y = 74
    foreach ($field in @(@('id','School ID'),@('password','Password'))) {
        $label = New-Object Windows.Forms.Label; $label.Text = $field[1]
        $label.Location = New-Object Drawing.Point(16,$y); $label.Size = New-Object Drawing.Size(170,24); $login.Controls.Add($label)
        $box = New-Object Windows.Forms.TextBox; $box.Location = New-Object Drawing.Point(192,$y)
        $box.Size = New-Object Drawing.Size(445,24)
        if ($field[0] -eq 'password') { $box.UseSystemPasswordChar = $true }
        $login.Controls.Add($box); $loginBoxes[$field[0]] = $box; $y += 48
    }
    $savedLogin = Get-LoginInfo
    if ($savedLogin) { $loginBoxes.id.Text = $savedLogin.id; $loginBoxes.password.Text = $savedLogin.password }
    $providerLabel = New-Object Windows.Forms.Label; $providerLabel.Text = 'School / trusted sign-in'
    $providerLabel.Location = New-Object Drawing.Point(16,174); $providerLabel.Size = New-Object Drawing.Size(170,24); $login.Controls.Add($providerLabel)
    $provider = New-Object Windows.Forms.ComboBox; $provider.DropDownStyle = 'DropDownList'
    $provider.Items.AddRange(@('HvA','UvA'))
    if ([string]$script:config.schoolProvider -eq 'uva' -or [string]$script:config.loginProvider -eq 'login.uva.nl') { $provider.SelectedItem = 'UvA' } else { $provider.SelectedItem = 'HvA' }
    $provider.Location = New-Object Drawing.Point(192,174); $provider.Size = New-Object Drawing.Size(445,24); $login.Controls.Add($provider)
    $clearLogin = New-Object Windows.Forms.Button; $clearLogin.Text = 'Clear saved login'; $clearLogin.Location = New-Object Drawing.Point(192,225)
    $clearLogin.Size = New-Object Drawing.Size(180,32)
    $clearLogin.Add_Click({
        Save-LoginInfo '' ''; $script:config.autoLoginEnabled = $false; Save-Config
        $loginBoxes.id.Clear(); $loginBoxes.password.Clear(); $autoLogin.Checked = $false
    }); $login.Controls.Add($clearLogin)
    $note = New-Object Windows.Forms.Label
    $note.Text = "Optional: leave both fields empty for manual login.`r`nSaved locally, encrypted for your Windows account. Never included in the shared ZIP.`r`nCampusBoop only autofills on the selected school's trusted ADFS host. It can also skip known school-choice buttons on trusted CampusBoop tool pages. Phone verification stays manual."
    $note.Location = New-Object Drawing.Point(16,285); $note.Size = New-Object Drawing.Size(640,118); $login.Controls.Add($note)

    # Weekly schedule
    $scheduled = New-Object Windows.Forms.CheckBox; $scheduled.Text = 'Only show automatic popups during these hours'
    $scheduled.Location = New-Object Drawing.Point(16,14); $scheduled.Size = New-Object Drawing.Size(620,24)
    $scheduled.Checked = [bool]$script:config.scheduleEnabled; $schedule.Controls.Add($scheduled)
    $caption = New-Object Windows.Forms.Label; $caption.Text = 'Day                         Start (HH:mm)       End (HH:mm)     Local Windows time'
    $caption.Location = New-Object Drawing.Point(16,48); $caption.Size = New-Object Drawing.Size(620,22); $schedule.Controls.Add($caption)
    $rows = @(); $y = 76
    foreach ($rule in $script:config.weeklySchedule) {
        $day = New-Object Windows.Forms.CheckBox; $day.Text = $rule.day; $day.Checked = [bool]$rule.enabled
        $day.Location = New-Object Drawing.Point(16,$y); $day.Size = New-Object Drawing.Size(145,24); $schedule.Controls.Add($day)
        $start = New-Object Windows.Forms.TextBox; $start.Text = $rule.start
        $start.Location = New-Object Drawing.Point(175,$y); $start.Size = New-Object Drawing.Size(100,24); $schedule.Controls.Add($start)
        $end = New-Object Windows.Forms.TextBox; $end.Text = $rule.end
        $end.Location = New-Object Drawing.Point(300,$y); $end.Size = New-Object Drawing.Size(100,24); $schedule.Controls.Add($end)
        $rows += [pscustomobject]@{name=$rule.day;day=$day;start=$start;end=$end}; $y += 40
    }
    $tip = New-Object Windows.Forms.Label; $tip.Text = 'Outside these hours CampusBoop keeps running, but automatic reminder popups stay quiet.'
    $tip.Location = New-Object Drawing.Point(16,366); $tip.Size = New-Object Drawing.Size(620,42); $schedule.Controls.Add($tip)

    # Behavior / startup
    $reminderLabel = New-Object Windows.Forms.Label
    $reminderLabel.Text = 'Commit + break reminder interval (minutes)'
    $reminderLabel.Location = New-Object Drawing.Point(16,24); $reminderLabel.Size = New-Object Drawing.Size(390,26); $behavior.Controls.Add($reminderLabel)
    $reminder = New-Object Windows.Forms.NumericUpDown; $reminder.Minimum = 1; $reminder.Maximum = 1440
    $reminder.Value = [Math]::Max(1,[Math]::Min(1440,[int]$script:config.reminderMinutes))
    $reminder.Location = New-Object Drawing.Point(420,24); $behavior.Controls.Add($reminder)
    $backgroundBox = New-Object Windows.Forms.CheckBox; $backgroundBox.Text = 'Keep CampusBoop running in the background when I close its window'
    $backgroundBox.Location = New-Object Drawing.Point(16,76); $backgroundBox.Size = New-Object Drawing.Size(625,34)
    $backgroundBox.Checked = [bool]$script:config.backgroundEnabled; $behavior.Controls.Add($backgroundBox)
    $startupBox = New-Object Windows.Forms.CheckBox; $startupBox.Text = 'Start CampusBoop automatically when I sign in to Windows'
    $startupBox.Location = New-Object Drawing.Point(16,122); $startupBox.Size = New-Object Drawing.Size(625,34)
    $startupBox.Checked = Test-StartupEnabled; $behavior.Controls.Add($startupBox)
    $smartBox = New-Object Windows.Forms.CheckBox; $smartBox.Text = 'Smart check-in reminder when I start working in VS Code'
    $smartBox.Location = New-Object Drawing.Point(16,168); $smartBox.Size = New-Object Drawing.Size(625,34)
    $smartBox.Checked = [bool]$script:config.smartReminderEnabled; $behavior.Controls.Add($smartBox)
    $startupReminder = New-Object Windows.Forms.CheckBox; $startupReminder.Text = 'Show one check-in reminder after computer startup'
    $startupReminder.Location = New-Object Drawing.Point(16,214); $startupReminder.Size = New-Object Drawing.Size(625,34)
    $startupReminder.Checked = [bool]$script:config.startupReminderEnabled; $behavior.Controls.Add($startupReminder)
    $delayLabel = New-Object Windows.Forms.Label; $delayLabel.Text = 'Startup reminder delay (minutes)'
    $delayLabel.Location = New-Object Drawing.Point(38,260); $delayLabel.Size = New-Object Drawing.Size(280,26); $behavior.Controls.Add($delayLabel)
    $delay = New-Object Windows.Forms.NumericUpDown; $delay.Minimum = 1; $delay.Maximum = 60
    $delay.Value = [Math]::Max(1,[Math]::Min(60,[int]$script:config.startupDelayMinutes))
    $delay.Location = New-Object Drawing.Point(330,260); $behavior.Controls.Add($delay)
    $behaviorNote = New-Object Windows.Forms.Label
    $behaviorNote.Text = "Startup reminder is only scheduled when CampusBoop itself starts in background mode.`r`nIf you mark yourself checked in, the smart check-in reminder stays quiet for the rest of that day.`r`nCommit/break reminders keep their normal VS Code behavior."
    $behaviorNote.Location = New-Object Drawing.Point(16,318); $behaviorNote.Size = New-Object Drawing.Size(630,96); $behavior.Controls.Add($behaviorNote)

    $save = New-Object Windows.Forms.Button; $save.Text = 'Save'; $save.Location = New-Object Drawing.Point(560,525); $save.Size = New-Object Drawing.Size(144,38)
    $save.Anchor = 'Bottom,Right'
    $save.Add_Click({
        foreach ($key in @('loginUrl','checkinUrl','option1Url','option2Url')) {
            $value = $boxes[$key].Text.Trim(); $uri = $null
            if ($key -like 'option*' -and $value -eq '') { continue }
            if (-not [Uri]::TryCreate($value,[UriKind]::Absolute,[ref]$uri) -or $uri.Scheme -ne 'https') { [Windows.Forms.MessageBox]::Show('School URLs must start with https://.','Settings') | Out-Null; return }
        }
        foreach ($key in @('tool1Url','tool2Url','tool3Url')) {
            $value = $toolBoxes[$key].Text.Trim(); $uri = $null
            if (-not [Uri]::TryCreate($value,[UriKind]::Absolute,[ref]$uri) -or $uri.Scheme -ne 'https') { [Windows.Forms.MessageBox]::Show('Student tool URLs must start with https://.','Settings') | Out-Null; return }
        }
        foreach ($key in @('tool1Name','tool2Name','tool3Name')) {
            if ([string]::IsNullOrWhiteSpace($toolBoxes[$key].Text)) { [Windows.Forms.MessageBox]::Show('Student tool names cannot be empty.','Settings') | Out-Null; return }
        }
        $minutes = 0
        if (-not [int]::TryParse($boxes.cooldownMinutes.Text,[ref]$minutes) -or $minutes -lt 1 -or $minutes -gt 1440) { [Windows.Forms.MessageBox]::Show('Choose an interval from 1 to 1440 minutes.','Settings') | Out-Null; return }
        $id = $loginBoxes.id.Text.Trim(); $password = $loginBoxes.password.Text
        if (($id -eq '') -ne ($password -eq '') -or ($autoLogin.Checked -and $id -eq '')) { [Windows.Forms.MessageBox]::Show('Enter both ID and password, or leave both empty and turn autofill off.','Settings') | Out-Null; return }
        $newSchedule = @()
        foreach ($row in $rows) {
            $startTime = [datetime]::MinValue; $endTime = [datetime]::MinValue
            $startOk = [datetime]::TryParseExact($row.start.Text,'HH:mm',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$startTime)
            $endOk = [datetime]::TryParseExact($row.end.Text,'HH:mm',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$endTime)
            if (-not $startOk -or -not $endOk -or ($row.day.Checked -and $startTime -eq $endTime)) { [Windows.Forms.MessageBox]::Show('Use HH:mm times with different start and end times (for example 09:00 and 17:00).','Settings') | Out-Null; return }
            $newSchedule += [pscustomobject]@{day=$row.name;enabled=$row.day.Checked;start=$row.start.Text;end=$row.end.Text}
        }
        Set-StartupEnabled $startupBox.Checked
        $script:config.backgroundEnabled = $backgroundBox.Checked
        $script:config.reminderMinutes = [int]$reminder.Value
        $script:config.smartReminderEnabled = $smartBox.Checked
        $script:config.startupReminderEnabled = $startupReminder.Checked
        $script:config.startupDelayMinutes = [int]$delay.Value
        Resume-Work
        Save-LoginInfo $id $password
        foreach ($key in $boxes.Keys) { $script:config.($key) = $boxes[$key].Text.Trim() }
        foreach ($key in $toolBoxes.Keys) { $script:config.($key) = $toolBoxes[$key].Text.Trim() }
        $script:config.cooldownMinutes = $minutes
        $school = if ([string]$provider.SelectedItem -eq 'UvA') { 'uva' } else { 'hva' }
        $script:config.schoolProvider = $school
        $script:config.loginProvider = if ($school -eq 'uva') { 'login.uva.nl' } else { 'login.hva.nl' }
        $script:config.autoLoginEnabled = $autoLogin.Checked
        $script:config.scheduleEnabled = $scheduled.Checked; $script:config.weeklySchedule = $newSchedule
        Save-Config; $f.Close()
    }); $f.Controls.Add($save)

    Set-BrandTheme $f; $f.ShowDialog() | Out-Null
    $loginBoxes.password.Clear(); $savedLogin = $null; $f.Dispose()
}

function Test-StartupEnabled {
    $folder = [Environment]::GetFolderPath('Startup')
    return ((Test-Path -LiteralPath (Join-Path $folder 'CampusBoop.lnk')) -or (Test-Path -LiteralPath (Join-Path $folder 'School Check-in.lnk')))
}

function Set-StartupEnabled([bool]$enabled) {
    $folder = [Environment]::GetFolderPath('Startup')
    $path = Join-Path $folder 'CampusBoop.lnk'
    if ($enabled) {
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($path)
        $shortcut.TargetPath = Join-Path $PSScriptRoot 'CampusBoop.exe'
        $shortcut.Arguments = '--background'; $shortcut.WorkingDirectory = $PSScriptRoot
        $shortcut.IconLocation = Join-Path $PSScriptRoot 'assets\creatorpromote.ico'
        $shortcut.Save()
    } elseif (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Force }
    $legacy = Join-Path $folder 'School Check-in.lnk'
    if (Test-Path -LiteralPath $legacy) { Remove-Item -LiteralPath $legacy -Force }
}

function Show-FirstRun {
    $f = New-Object Windows.Forms.Form; $f.Text = 'Welcome to CampusBoop v1.1'
    $f.StartPosition = 'CenterScreen'; $f.ClientSize = New-Object Drawing.Size(620,470)
    $label = New-Object Windows.Forms.Label
    $label.Text = "Meet Boop! Your check-in, commit and break reminder.`r`nChoose your school and how you want CampusBoop to remind you. Everything can be changed later in Settings."
    $label.Location = New-Object Drawing.Point(20,20); $label.Size = New-Object Drawing.Size(580,64); $f.Controls.Add($label)

    $schoolLabel = New-Object Windows.Forms.Label; $schoolLabel.Text = 'School'
    $schoolLabel.Location = New-Object Drawing.Point(20,98); $schoolLabel.Size = New-Object Drawing.Size(170,24); $f.Controls.Add($schoolLabel)
    $school = New-Object Windows.Forms.ComboBox; $school.DropDownStyle = 'DropDownList'; $school.Items.AddRange(@('HvA','UvA'))
    if ([string]$script:config.schoolProvider -eq 'uva') { $school.SelectedItem = 'UvA' } else { $school.SelectedItem = 'HvA' }
    $school.Location = New-Object Drawing.Point(200,98); $school.Size = New-Object Drawing.Size(300,24); $f.Controls.Add($school)

    $background = New-Object Windows.Forms.CheckBox
    $background.Text = 'Allow CampusBoop to run quietly in the background'
    $background.Checked = $true; $background.Location = New-Object Drawing.Point(20,145)
    $background.Size = New-Object Drawing.Size(570,34); $f.Controls.Add($background)

    $startup = New-Object Windows.Forms.CheckBox
    $startup.Text = 'Start CampusBoop automatically when I sign in to Windows'
    $startup.Checked = $true; $startup.Location = New-Object Drawing.Point(20,188)
    $startup.Size = New-Object Drawing.Size(570,34); $f.Controls.Add($startup)

    $smart = New-Object Windows.Forms.CheckBox
    $smart.Text = 'Smart check-in reminder when I start working in VS Code'
    $smart.Checked = $true; $smart.Location = New-Object Drawing.Point(20,231)
    $smart.Size = New-Object Drawing.Size(570,34); $f.Controls.Add($smart)

    $startupReminder = New-Object Windows.Forms.CheckBox
    $startupReminder.Text = 'Show one check-in reminder after computer startup'
    $startupReminder.Checked = $true; $startupReminder.Location = New-Object Drawing.Point(20,274)
    $startupReminder.Size = New-Object Drawing.Size(570,34); $f.Controls.Add($startupReminder)

    $delayLabel = New-Object Windows.Forms.Label; $delayLabel.Text = 'Startup reminder delay'
    $delayLabel.Location = New-Object Drawing.Point(42,320); $delayLabel.Size = New-Object Drawing.Size(180,24); $f.Controls.Add($delayLabel)
    $delay = New-Object Windows.Forms.NumericUpDown; $delay.Minimum = 1; $delay.Maximum = 60; $delay.Value = 2
    $delay.Location = New-Object Drawing.Point(230,320); $delay.Size = New-Object Drawing.Size(80,24); $f.Controls.Add($delay)
    $delayUnit = New-Object Windows.Forms.Label; $delayUnit.Text = 'minutes'; $delayUnit.Location = New-Object Drawing.Point(318,320); $delayUnit.Size = New-Object Drawing.Size(100,24); $f.Controls.Add($delayUnit)

    $note = New-Object Windows.Forms.Label
    $note.Text = 'CampusBoop will also prepare Print, Top up and Library buttons for the school you choose. You can rename or replace those links later.'
    $note.Location = New-Object Drawing.Point(20,365); $note.Size = New-Object Drawing.Size(580,48); $f.Controls.Add($note)

    $start = New-Object Windows.Forms.Button; $start.Text = 'Save choices and start'
    $start.Location = New-Object Drawing.Point(370,421); $start.Size = New-Object Drawing.Size(230,36)
    $start.Anchor = 'Bottom,Right'; $f.Controls.Add($start)
    $start.Add_Click({
        $schoolKey = if ([string]$school.SelectedItem -eq 'UvA') { 'uva' } else { 'hva' }
        Apply-StudentToolDefaults $schoolKey
        Set-StartupEnabled $startup.Checked
        $script:config.backgroundEnabled = $background.Checked
        $script:config.smartReminderEnabled = $smart.Checked
        $script:config.startupReminderEnabled = $startupReminder.Checked
        $script:config.startupDelayMinutes = [int]$delay.Value
        $script:config.onboardingComplete = $true; Save-Config
        $f.DialogResult = [Windows.Forms.DialogResult]::OK; $f.Close()
    })
    Set-BrandTheme $f
    $result = $f.ShowDialog(); $f.Dispose()
    return ($result -eq [Windows.Forms.DialogResult]::OK)
}
