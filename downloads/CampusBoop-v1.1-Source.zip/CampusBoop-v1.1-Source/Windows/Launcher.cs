using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows.Forms;

[assembly: System.Reflection.AssemblyTitle("CampusBoop")]
[assembly: System.Reflection.AssemblyVersion("1.1.0.0")]
[assembly: System.Reflection.AssemblyFileVersion("1.1.0.0")]

internal static class Launcher
{
    [STAThread]
    private static void Main(string[] args)
    {
        try
        {
            string folder = AppDomain.CurrentDomain.BaseDirectory;
            string script = Path.Combine(folder, "SchoolCheckIn.ps1");
            var start = new ProcessStartInfo {
                FileName = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), @"WindowsPowerShell\v1.0\powershell.exe"),
                WorkingDirectory = folder,
                UseShellExecute = false,
                CreateNoWindow = true,
                WindowStyle = ProcessWindowStyle.Hidden
            };
            if (args.Length == 2 && args[0] == "--probe")
            {
                string output = Path.GetFullPath(args[1]).Replace("'", "''");
                string command = "Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class ConsoleProbe { [DllImport(\"kernel32.dll\")] public static extern IntPtr GetConsoleWindow(); }'; " +
                    "@{consoleHandle=[ConsoleProbe]::GetConsoleWindow().ToInt64();pid=$PID} | ConvertTo-Json | Set-Content -LiteralPath '" + output + "' -Encoding UTF8";
                start.Arguments = "-NoProfile -NonInteractive -EncodedCommand " + Convert.ToBase64String(Encoding.Unicode.GetBytes(command));
                using (var process = Process.Start(start)) { process.WaitForExit(); }
                return;
            }
            if (!File.Exists(script)) throw new FileNotFoundException("Keep SchoolCheckIn.ps1 beside CampusBoop.exe.");
            start.Arguments = "-NoProfile -ExecutionPolicy Bypass -STA -File \"" + script + "\"";
            if (Array.IndexOf(args, "--background") >= 0) start.Arguments += " -Background";
            Process.Start(start);
        }
        catch (Exception error) { MessageBox.Show(error.Message, "CampusBoop", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }
}
