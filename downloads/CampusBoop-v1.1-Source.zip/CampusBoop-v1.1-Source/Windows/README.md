# CampusBoop v1.1 — Windows x64

CampusBoop is an independent student-made helper for HvA/UvA study workflows. It is not an official HvA or UvA application.

## Start

Run `CampusBoop.exe` or use the Start Menu shortcut created by the website installer.

On the first start, CampusBoop asks you to choose HvA or UvA and lets you choose:

- start CampusBoop automatically with Windows;
- show one check-in reminder shortly after startup;
- use the smart VS Code check-in reminder;
- the delay before the startup reminder.

All of those choices can be changed later in **Settings**.

## Student tools

The bottom of the main window contains three editable quick links:

- Print
- Top up
- Library

HvA and UvA presets are included. Names and URLs can be changed freely in **Settings > Student tools**.

## Login helper

Windows can optionally save a school ID/password locally using Windows DPAPI. Autofill is restricted to the selected trusted ADFS host (`login.hva.nl` or `login.uva.nl`). CampusBoop never stores those credentials on the website.

For known CampusBoop student-tool pages, the embedded trusted browser can also try to skip a school/student choice button based on whether HvA or UvA is selected. It only does this on explicitly recognised HTTPS school-service hosts. MFA/phone verification stays manual.

## Manual removal on Windows

CampusBoop intentionally does not require an uninstall command.

1. Exit CampusBoop from the tray, or end it in Task Manager if it is still running.
2. Search Windows for **CampusBoop**.
3. Choose **Open file location**.
4. If Windows opens a shortcut, right-click that CampusBoop shortcut and choose **Open file location** again to reach the real app folder.
5. Delete the entire **CampusBoop** folder.
6. Delete the CampusBoop shortcut from the first location.
7. If you enabled startup, remove the CampusBoop startup shortcut as well.

Your personal settings are stored separately under `%LOCALAPPDATA%\SchoolCheckInHelper`. Delete that folder only if you also want to remove settings and any DPAPI-encrypted saved login.

## Files

`CampusBoop.exe` is a small launcher for `SchoolCheckIn.ps1`. The source files remain beside the app so the release stays inspectable. `SchoolLogin.exe` uses Microsoft Edge WebView2; if the included source is newer than the helper executable, CampusBoop recompiles the helper locally with Windows PowerShell/.NET before using it.
