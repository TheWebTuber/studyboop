# CampusBoop v1.0 — Linux

CampusBoop is an independent student-made reminder helper for HvA/UvA study workflows. It is not made, endorsed, supported, or distributed by Hogeschool van Amsterdam or Universiteit van Amsterdam.

## Recommended installation

Use the one-command installer from:
https://campusboop.creatorpromote.com/#download

It detects Linux x64 or ARM64, verifies the SHA-256 checksum, installs CampusBoop for the current user, and creates the `campusboop` command.

## Commands

- `campusboop` — open CampusBoop
- `campusboop --background` — run quietly in the background
- `campusboop --autostart-on` — start CampusBoop when you sign in
- `campusboop --autostart-off` — disable sign-in startup
- `campusboop --help` — show commands
- `campusboop --uninstall` — remove the app files and startup entry
- `campusboop --purge` — remove the app plus saved local CampusBoop settings

## Linux behavior

The Linux build is a self-contained native executable. Its controls are served only to `127.0.0.1` and opened in your normal browser. School links open in your normal browser over HTTPS. CampusBoop does not automatically submit school check-in/check-out forms.

VS Code detection works directly from Linux process information. On X11, if `xdotool` is installed, CampusBoop can also check whether VS Code is the active window. On Wayland or systems without `xdotool`, it falls back to whether VS Code is currently running.

Desktop notifications use `notify-send` when it is available. The actionable CampusBoop page still opens for due reminders.

## Local data

Settings/state are stored under `${XDG_CONFIG_HOME:-~/.config}/campusboop`.

No HvA/UvA password is stored by the Linux build. Authentication stays in your normal browser and MFA/phone verification stays manual.
