# CampusBoop v1.0 — source package

CampusBoop is an independent student-made project and is not made, endorsed, supported, or distributed by Hogeschool van Amsterdam or Universiteit van Amsterdam.

This source package contains:
- `Windows/` — the supplied CampusBoop v1.0 Windows PowerShell/C# source and runtime files.
- `Linux/` — the Linux Go implementation and embedded local browser UI source.
- `Website/` — the one-page public website plus Windows/Linux one-command installers.

The Linux release binaries are built with Go as statically linked `linux/amd64` and `linux/arm64` executables.
