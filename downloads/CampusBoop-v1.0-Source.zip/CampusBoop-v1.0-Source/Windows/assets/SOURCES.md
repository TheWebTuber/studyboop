# Logo sources

HvA logo: SVG from https://www.hva.nl/ (wide logo in the website header), downloaded 5 October 2026. The path shapes are preserved and rendered in purple for this interface.

UvA logo: Dutch large logo symbol from https://www.uva.nl/webfiles/1790927060797/icons/svg-logos.svg, downloaded 5 October 2026. The path shapes are preserved.

The supplied PNGs are raster renderings of these SVGs for Windows Forms. This is a personal student helper, not an official HvA or UvA application.

CreatorPromote-style icon: original vector consisting of four purple squares, drawn from the user's description. The referenced hva.creatorpromote.com could not be resolved; no official icon asset was retrieved.
