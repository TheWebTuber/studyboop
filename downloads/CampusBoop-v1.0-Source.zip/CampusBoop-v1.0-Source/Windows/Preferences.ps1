﻿Add-Type -AssemblyName System.Security
function New-WeekSchedule {
    @('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') | ForEach-Object {
        [pscustomobject]@{ day = $_; enabled = ($_ -notin @('Saturday','Sunday')); start = '09:00'; end = '17:00' }
    }
}
function Test-AlarmTime([datetime]$now) {
    if (-not $script:config.scheduleEnabled) { return $true }
    $today = $now.DayOfWeek.ToString(); $previous = $now.AddDays(-1).DayOfWeek.ToString()
    $minute = $now.Hour * 60 + $now.Minute
    foreach ($rule in $script:config.weeklySchedule) {
        if (-not $rule.enabled) { continue }
        $startTime = [datetime]::MinValue; $endTime = [datetime]::MinValue
        if (-not [datetime]::TryParseExact([string]$rule.start,'HH:mm',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$startTime)) { continue }
        if (-not [datetime]::TryParseExact([string]$rule.end,'HH:mm',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$endTime)) { continue }
        $startMinute = $startTime.Hour * 60 + $startTime.Minute; $endMinute = $endTime.Hour * 60 + $endTime.Minute
        if ($startMinute -lt $endMinute -and $rule.day -eq $today -and $minute -ge $startMinute -and $minute -lt $endMinute) { return $true }
        if ($startMinute -gt $endMinute -and (($rule.day -eq $today -and $minute -ge $startMinute) -or ($rule.day -eq $previous -and $minute -lt $endMinute))) { return $true }
    }
    return $false
}
function Get-LoginInfo {
    $path = Join-Path $script:dataDir 'login.bin'
    if (-not (Test-Path -LiteralPath $path)) { return $null }
    try {
        $bytes = [Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes($path),$null,[Security.Cryptography.DataProtectionScope]::CurrentUser)
        $value = [Text.Encoding]::UTF8.GetString($bytes) | ConvertFrom-Json
        [Array]::Clear($bytes,0,$bytes.Length)
        return $value
    } catch {
        [Windows.Forms.MessageBox]::Show('Saved login could not be unlocked. Enter it again or clear it in Settings.','School Check-in') | Out-Null
        return $null
    }
}
function Save-LoginInfo([string]$id,[string]$password) {
    $path = Join-Path $script:dataDir 'login.bin'
    if ($id -eq '' -and $password -eq '') { if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path }; return }
    $bytes = [Text.Encoding]::UTF8.GetBytes((@{id=$id;password=$password} | ConvertTo-Json -Compress))
    try {
        $protected = [Security.Cryptography.ProtectedData]::Protect($bytes,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser)
        [IO.File]::WriteAllBytes($path,$protected)
    } finally { [Array]::Clear($bytes,0,$bytes.Length) }
}
function Show-Settings {
    $f = New-Object Windows.Forms.Form
    $f.Text = 'Personal settings'; $f.ClientSize = New-Object Drawing.Size(660,470)
    $f.StartPosition = 'CenterScreen'; $f.FormBorderStyle = 'FixedDialog'; $f.MaximizeBox = $false
    $tabs = New-Object Windows.Forms.TabControl
    $tabs.Location = New-Object Drawing.Point(16,12); $tabs.Size = New-Object Drawing.Size(628,385)
    $links = New-Object Windows.Forms.TabPage; $links.Text = 'School links'
    $login = New-Object Windows.Forms.TabPage; $login.Text = 'Personal login'
    $schedule = New-Object Windows.Forms.TabPage; $schedule.Text = 'Weekly reminders'
    $behavior = New-Object Windows.Forms.TabPage; $behavior.Text = 'Boop / startup'
    $tabs.TabPages.AddRange(@($links,$login,$schedule,$behavior)); $f.Controls.Add($tabs)
    $tabs.Anchor = 'Top,Bottom,Left,Right'
    $reminderLabel = New-Object Windows.Forms.Label
    $reminderLabel.Text = 'Commit + break reminder interval (minutes)'
    $reminderLabel.Location = New-Object Drawing.Point(16,25); $reminderLabel.Size = New-Object Drawing.Size(370,26); $behavior.Controls.Add($reminderLabel)
    $reminder = New-Object Windows.Forms.NumericUpDown; $reminder.Minimum = 1; $reminder.Maximum = 1440
    $reminder.Value = [Math]::Max(1,[Math]::Min(1440,[int]$script:config.reminderMinutes))
    $reminder.Location = New-Object Drawing.Point(400,25); $behavior.Controls.Add($reminder)
    $backgroundBox = New-Object Windows.Forms.CheckBox; $backgroundBox.Text = 'Keep CampusBoop running in the background when I close its window'
    $backgroundBox.Location = New-Object Drawing.Point(16,83); $backgroundBox.Size = New-Object Drawing.Size(580,45)
    $backgroundBox.Checked = [bool]$script:config.backgroundEnabled; $behavior.Controls.Add($backgroundBox)
    $startupBox = New-Object Windows.Forms.CheckBox; $startupBox.Text = 'Start CampusBoop automatically when I sign in to Windows'
    $startupBox.Location = New-Object Drawing.Point(16,145); $startupBox.Size = New-Object Drawing.Size(580,40)
    $startupBox.Checked = Test-StartupEnabled; $behavior.Controls.Add($startupBox)
    $behaviorNote = New-Object Windows.Forms.Label
    $behaviorNote.Text = "Default: Boop reminds you every 45 minutes while VS Code is active.`r`nTake a break silences automatic reminders for 10 minutes.`r`nWith background enabled, X closes the main window and the tray stays on.`r`nChoose Exit from the tray menu to stop CampusBoop completely."
    $behaviorNote.Location = New-Object Drawing.Point(16,215); $behaviorNote.Size = New-Object Drawing.Size(580,110); $behavior.Controls.Add($behaviorNote)
    $fields = @(@('loginUrl','School login URL'),@('checkinUrl','Shared check-in URL'),@('option1Name','First option name'),@('option1Url','First option URL (optional)'),@('option2Name','Second option name'),@('option2Url','Second option URL (optional)'),@('cooldownMinutes','Check-in interval (minutes)'))
    $boxes = @{}; $y = 20
    foreach ($field in $fields) {
        $label = New-Object Windows.Forms.Label; $label.Text = $field[1]
        $label.Location = New-Object Drawing.Point(12,$y); $label.Size = New-Object Drawing.Size(195,22); $links.Controls.Add($label)
        $box = New-Object Windows.Forms.TextBox; $box.Text = [string]$script:config.($field[0])
        $box.Location = New-Object Drawing.Point(212,$y); $box.Size = New-Object Drawing.Size(385,24)
        $links.Controls.Add($box); $boxes[$field[0]] = $box; $y += 43
    }
    $autoLogin = New-Object Windows.Forms.CheckBox
    $autoLogin.Text = 'Fill and submit my saved school login automatically'
    $autoLogin.Location = New-Object Drawing.Point(16,18); $autoLogin.Size = New-Object Drawing.Size(570,26)
    $autoLogin.Checked = [bool]$script:config.autoLoginEnabled; $login.Controls.Add($autoLogin)
    $loginBoxes = @{}; $y = 66
    foreach ($field in @(@('id','School ID'),@('password','Password'))) {
        $label = New-Object Windows.Forms.Label; $label.Text = $field[1]
        $label.Location = New-Object Drawing.Point(16,$y); $label.Size = New-Object Drawing.Size(170,24); $login.Controls.Add($label)
        $box = New-Object Windows.Forms.TextBox; $box.Location = New-Object Drawing.Point(192,$y)
        $box.Size = New-Object Drawing.Size(395,24)
        if ($field[0] -eq 'password') { $box.UseSystemPasswordChar = $true }
        $login.Controls.Add($box); $loginBoxes[$field[0]] = $box; $y += 44
    }
    $savedLogin = Get-LoginInfo
    if ($savedLogin) { $loginBoxes.id.Text = $savedLogin.id; $loginBoxes.password.Text = $savedLogin.password }
    $providerLabel = New-Object Windows.Forms.Label; $providerLabel.Text = 'Trusted sign-in site'
    $providerLabel.Location = New-Object Drawing.Point(16,154); $providerLabel.Size = New-Object Drawing.Size(170,24); $login.Controls.Add($providerLabel)
    $provider = New-Object Windows.Forms.ComboBox; $provider.DropDownStyle = 'DropDownList'
    $provider.Items.AddRange(@('login.hva.nl','login.uva.nl')); $provider.SelectedItem = $script:config.loginProvider
    $provider.Location = New-Object Drawing.Point(192,154); $provider.Size = New-Object Drawing.Size(395,24); $login.Controls.Add($provider)
    $clearLogin = New-Object Windows.Forms.Button; $clearLogin.Text = 'Clear saved login'; $clearLogin.Location = New-Object Drawing.Point(192,205)
    $clearLogin.Size = New-Object Drawing.Size(180,32)
    $clearLogin.Add_Click({
        Save-LoginInfo '' ''; $script:config.autoLoginEnabled = $false; Save-Config
        $loginBoxes.id.Clear(); $loginBoxes.password.Clear(); $autoLogin.Checked = $false
    }); $login.Controls.Add($clearLogin)
    $note = New-Object Windows.Forms.Label
    $note.Text = "Optional: leave both fields empty for manual login.`r`nSaved locally, encrypted for your Windows account. Never included in the shared ZIP.`r`nAutofill uses the helper's login window. Phone verification stays manual."
    $note.Location = New-Object Drawing.Point(16,259); $note.Size = New-Object Drawing.Size(580,86); $login.Controls.Add($note)
    $scheduled = New-Object Windows.Forms.CheckBox; $scheduled.Text = 'Only show automatic popups during these hours'
    $scheduled.Location = New-Object Drawing.Point(16,14); $scheduled.Size = New-Object Drawing.Size(580,24)
    $scheduled.Checked = [bool]$script:config.scheduleEnabled; $schedule.Controls.Add($scheduled)
    $caption = New-Object Windows.Forms.Label; $caption.Text = 'Day                         Start (HH:mm)       End (HH:mm)     Local Windows time'
    $caption.Location = New-Object Drawing.Point(16,48); $caption.Size = New-Object Drawing.Size(580,22); $schedule.Controls.Add($caption)
    $rows = @(); $y = 76
    foreach ($rule in $script:config.weeklySchedule) {
        $day = New-Object Windows.Forms.CheckBox; $day.Text = $rule.day; $day.Checked = [bool]$rule.enabled
        $day.Location = New-Object Drawing.Point(16,$y); $day.Size = New-Object Drawing.Size(145,24); $schedule.Controls.Add($day)
        $start = New-Object Windows.Forms.TextBox; $start.Text = $rule.start
        $start.Location = New-Object Drawing.Point(175,$y); $start.Size = New-Object Drawing.Size(100,24); $schedule.Controls.Add($start)
        $end = New-Object Windows.Forms.TextBox; $end.Text = $rule.end
        $end.Location = New-Object Drawing.Point(300,$y); $end.Size = New-Object Drawing.Size(100,24); $schedule.Controls.Add($end)
        $rows += [pscustomobject]@{name=$rule.day;day=$day;start=$start;end=$end}; $y += 33
    }
    $tip = New-Object Windows.Forms.Label; $tip.Text = 'Off by default. Outside hours: tray stays running, popups stay quiet.'
    $tip.Location = New-Object Drawing.Point(16,316); $tip.Size = New-Object Drawing.Size(580,30); $schedule.Controls.Add($tip)
    $save = New-Object Windows.Forms.Button; $save.Text = 'Save'; $save.Location = New-Object Drawing.Point(520,414); $save.Size = New-Object Drawing.Size(124,34)
    $save.Anchor = 'Bottom,Right'
    $save.Add_Click({
        foreach ($key in @('loginUrl','checkinUrl','option1Url','option2Url')) {
            $value = $boxes[$key].Text.Trim(); $uri = $null
            if ($key -like 'option*' -and $value -eq '') { continue }
            if (-not [Uri]::TryCreate($value,[UriKind]::Absolute,[ref]$uri) -or $uri.Scheme -ne 'https') { [Windows.Forms.MessageBox]::Show('URLs must start with https://.','Settings') | Out-Null; return }
        }
        $minutes = 0
        if (-not [int]::TryParse($boxes.cooldownMinutes.Text,[ref]$minutes) -or $minutes -lt 1 -or $minutes -gt 1440) { [Windows.Forms.MessageBox]::Show('Choose an interval from 1 to 1440 minutes.','Settings') | Out-Null; return }
        $id = $loginBoxes.id.Text.Trim(); $password = $loginBoxes.password.Text
        if (($id -eq '') -ne ($password -eq '') -or ($autoLogin.Checked -and $id -eq '')) { [Windows.Forms.MessageBox]::Show('Enter both ID and password, or leave both empty and turn autofill off.','Settings') | Out-Null; return }
        $newSchedule = @()
        foreach ($row in $rows) {
            $startTime = [datetime]::MinValue; $endTime = [datetime]::MinValue
            $startOk = [datetime]::TryParseExact($row.start.Text,'HH:mm',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$startTime)
            $endOk = [datetime]::TryParseExact($row.end.Text,'HH:mm',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$endTime)
            if (-not $startOk -or -not $endOk -or ($row.day.Checked -and $startTime -eq $endTime)) { [Windows.Forms.MessageBox]::Show('Use HH:mm times with different start and end times (for example 09:00 and 17:00).','Settings') | Out-Null; return }
            $newSchedule += [pscustomobject]@{day=$row.name;enabled=$row.day.Checked;start=$row.start.Text;end=$row.end.Text}
        }
        Set-StartupEnabled $startupBox.Checked
        $script:config.backgroundEnabled = $backgroundBox.Checked
        $script:config.reminderMinutes = [int]$reminder.Value
        Resume-Work
        Save-LoginInfo $id $password
        foreach ($key in $boxes.Keys) { $script:config.($key) = $boxes[$key].Text.Trim() }
        $script:config.cooldownMinutes = $minutes
        $script:config.autoLoginEnabled = $autoLogin.Checked; $script:config.loginProvider = [string]$provider.SelectedItem
        $script:config.scheduleEnabled = $scheduled.Checked; $script:config.weeklySchedule = $newSchedule
        Save-Config; $f.Close()
    }); $f.Controls.Add($save)
    Set-BrandTheme $f; $f.ShowDialog() | Out-Null
    $loginBoxes.password.Clear(); $savedLogin = $null; $f.Dispose()
}

function Test-StartupEnabled {
    $folder = [Environment]::GetFolderPath('Startup')
    return ((Test-Path -LiteralPath (Join-Path $folder 'CampusBoop.lnk')) -or (Test-Path -LiteralPath (Join-Path $folder 'School Check-in.lnk')))
}
function Set-StartupEnabled([bool]$enabled) {
    $folder = [Environment]::GetFolderPath('Startup')
    $path = Join-Path $folder 'CampusBoop.lnk'
    if ($enabled) {
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($path)
        $shortcut.TargetPath = Join-Path $PSScriptRoot 'CampusBoop.exe'
        $shortcut.Arguments = '--background'; $shortcut.WorkingDirectory = $PSScriptRoot
        $shortcut.Save()
    } elseif (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path }
    $legacy = Join-Path $folder 'School Check-in.lnk'
    if (Test-Path -LiteralPath $legacy) { Remove-Item -LiteralPath $legacy }
}
function Show-FirstRun {
    $f = New-Object Windows.Forms.Form; $f.Text = 'Welcome to CampusBoop v1.0'
    $f.StartPosition = 'CenterScreen'; $f.ClientSize = New-Object Drawing.Size(560,310)
    $label = New-Object Windows.Forms.Label
    $label.Text = "Meet Boop! Your check-in, commit, and break reminder.`r`nChoose how CampusBoop runs on this computer. You can change these choices in Settings any time."
    $label.Location = New-Object Drawing.Point(20,20); $label.Size = New-Object Drawing.Size(520,64); $f.Controls.Add($label)
    $background = New-Object Windows.Forms.CheckBox
    $background.Text = 'Allow CampusBoop to run in the background (no console window)'
    $background.Checked = $true; $background.Location = New-Object Drawing.Point(20,101)
    $background.Size = New-Object Drawing.Size(520,40); $f.Controls.Add($background)
    $startup = New-Object Windows.Forms.CheckBox
    $startup.Text = 'Start automatically when I sign in to Windows'
    $startup.Checked = Test-StartupEnabled; $startup.Location = New-Object Drawing.Point(20,151)
    $startup.Size = New-Object Drawing.Size(520,35); $f.Controls.Add($startup)
    $note = New-Object Windows.Forms.Label
    $note.Text = 'Your school login starts empty. Add your own links and optional login in Settings.'
    $note.Location = New-Object Drawing.Point(20,200); $note.Size = New-Object Drawing.Size(520,40); $f.Controls.Add($note)
    $start = New-Object Windows.Forms.Button; $start.Text = 'Save choices and start'
    $start.Location = New-Object Drawing.Point(320,256); $start.Size = New-Object Drawing.Size(220,35)
    $start.Anchor = 'Bottom,Right'; $f.Controls.Add($start)
    $start.Add_Click({
        Set-StartupEnabled $startup.Checked
        $script:config.backgroundEnabled = $background.Checked
        $script:config.onboardingComplete = $true; Save-Config
        $f.DialogResult = [Windows.Forms.DialogResult]::OK; $f.Close()
    })
    Set-BrandTheme $f
    $result = $f.ShowDialog(); $f.Dispose()
    return ($result -eq [Windows.Forms.DialogResult]::OK)
}
