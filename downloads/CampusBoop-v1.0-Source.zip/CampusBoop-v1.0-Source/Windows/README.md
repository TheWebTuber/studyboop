# CampusBoop v1.0 — Windows x64

Meet **Boop**, your school check-in, commit/push, and break reminder.

## Start here

Extract the whole ZIP to a permanent folder. Open **CampusBoop.exe**. No terminal or console window stays on screen. On first launch, choose:

- **Allow CampusBoop to run in the background**: X closes the main window, while the tray icon and reminders remain active. Untick this to exit the helper when the main window closes.
- **Start automatically when I sign in to Windows**: optional and off for new installations. Startup launches quietly in the tray when background mode is enabled.

Click **Save choices and start**. You can change both choices later under **Settings → Boop / startup**. This is a portable app, so there is no separate installer. Keep all supplied files together and keep the folder in place if startup is enabled.

Double-click the four-purple-squares tray icon or open CampusBoop.exe again to reopen the main window. Windows have normal minimize, maximize, resize, and X controls. Maximize fills the desktop work area. **Exit** in the tray menu stops the background helper completely.

## Boop reminders

The combined commit/push and break alert defaults to **45 minutes**, adjustable from 1–1440 minutes in Settings. It reminds you to save your work with commits/pushes and take a break once in a while. Choose:

- **Got it — thanks, Boop** or **Keep working**: dismiss the alert; the next interval begins from dismissal.
- **Take a break**: silence automatic reminders for 10 minutes. The next combined reminder is scheduled one configured interval after the break ends.
- **X**: dismiss the alert, just like Got it.

Use **Resume work** in the tray menu or main window to end a break early. Boop does not automatically commit, push, or record work hours. The interval uses elapsed clock time: a due reminder waits until VS Code is foreground and your weekly schedule allows it. Missed reminders do not accumulate.

Check-in reminders use a separate interval, default 60 minutes. **Already checked in today** stops today's check-in prompts while keeping Boop's commit and break reminders. **Checked out for today** stops all reminders for today. Those choices record local status only. **Enable reminders again today** resets both statuses.

Closing the last detected VS Code window prompts you to save work and check out, within your allowed reminder hours. All VS Code projects can trigger reminders. Pause, break time, checkout, and the weekly schedule suppress automatic alerts. Daily status expires the next calendar day.

## School links and optional personal login

Settings has four tabs: **School links**, **Personal login**, **Weekly reminders**, and **Boop / startup**. The main window also has a Settings button.

Customize the HTTPS login URL, shared check-in URL, two option names and optional links. Blank option links use the shared page. Log in, choose the check-in, describe your work, and submit it yourself. CampusBoop does not submit school check-in or checkout forms automatically.

Personal login starts empty and autofill is off. You can keep manual sign-in. Optional autofill fills and submits saved ID/password once on the selected trusted school's supported ADFS sign-in page. Phone verification remains manual. Supported providers: login.hva.nl and login.uva.nl. Different login layouts may need manual entry.

Saved credentials are encrypted with Windows DPAPI for your Windows account in `%LOCALAPPDATA%\SchoolCheckInHelper\login.bin`. They are not included in this folder or ZIP. Unchecking autofill retains the saved login; **Clear saved login** removes it. Programs running as your Windows account can access your saved credentials. Share the supplied ZIP, not your LocalAppData folder.

The optional login browser requires Microsoft Edge WebView2 Runtime. If it cannot start, use its normal-browser button for manual sign-in. Its separate browser profile is stored under `%LOCALAPPDATA%\SchoolCheckInHelper\BrowserProfile`. Sign out there to clear a retained school session. No real school login or phone verification was performed during development.

## Weekly schedule

Scheduling is off by default. Enable **Only show automatic popups during these hours**, select days, and enter 24-hour HH:mm start/end times. Outside these windows the app stays available but automatic alerts stay quiet. Times use your Windows clock; start is included and end is excluded. Overnight windows work, such as Friday 22:00–02:00. Equal start/end times are not allowed. No enabled days means no automatic reminders.

## Update, share, or remove

Exit the previous helper from its tray menu before starting v1.0. Existing links, encrypted login, and daily status are retained in the same local data directory. First-run setup also appears once for existing users. An enabled legacy School Check-in startup shortcut is replaced with CampusBoop's shortcut after setup.

Share **CampusBoop-v1.0.zip**. Each classmate saves their own links, login, and schedule on their own Windows account.

To remove: disable Windows startup in Settings, choose Exit, close any school-login windows, and delete the extracted app folder. Optionally delete `%LOCALAPPDATA%\SchoolCheckInHelper` to erase your saved settings, encrypted login, and browser profile.

## Build and validation

Launcher.cs and SchoolLogin.cs are included, alongside the PowerShell application sources. The launcher is a Windows GUI executable with version 1.0.0.0 and starts PowerShell without an attached console (verified console handle: 0). The optional login browser targets Windows x64. WebView2 SDK binaries and license are included.

Validation covered 45-minute timing, check-in/checkout, pause, break suppression and resumption, duplicate alert prevention, weekly/overnight schedule boundaries, encrypted credential round-trip and clearing, and rendering all windows/settings tabs. Maximize/resize controls and button bounds were checked. Live Windows sign-in startup and real school authentication still need testing on the user's computer.

HvA/UvA assets and the existing four-purple-squares icon are retained. Asset source notes are in assets/SOURCES.md. CampusBoop is a student project.
