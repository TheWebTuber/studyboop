using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

internal sealed class SchoolLogin : Form
{
    private readonly WebView2 browser = new WebView2();
    private readonly TextBox address = new TextBox();
    private readonly Label status = new Label();
    private readonly Timer timer = new Timer();
    private readonly string initialUrl;
    private readonly string dataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SchoolCheckInHelper");
    private bool submitted, busy;
    private readonly JavaScriptSerializer json = new JavaScriptSerializer();

    [STAThread]
    private static void Main(string[] args)
    {
        Application.EnableVisualStyles();
        Uri uri;
        if (args.Length != 2 || args[0] != "--url" || !Uri.TryCreate(args[1], UriKind.Absolute, out uri) || uri.Scheme != "https") return;
        Application.Run(new SchoolLogin(uri.AbsoluteUri));
    }
    private SchoolLogin(string url)
    {
        initialUrl = url;
        Text = "CampusBoop - School login";
        Size = new Size(1100, 800); StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 10);
        string icon = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"assets\creatorpromote.ico");
        if (File.Exists(icon)) Icon = new Icon(icon);
        var header = new Panel { Dock = DockStyle.Top, Height = 88, BackColor = Color.FromArgb(244,243,250) };
        address.ReadOnly = true; address.Dock = DockStyle.Top; address.Height = 28;
        status.Dock = DockStyle.Fill; status.Padding = new Padding(12); status.Text = "Loading school login. Phone verification remains manual.";
        header.Controls.Add(status); header.Controls.Add(address);
        browser.Dock = DockStyle.Fill; Controls.Add(browser); Controls.Add(header);
        timer.Interval = 1000;
        timer.Tick += async delegate { await TryLogin(); };
        Shown += async delegate { await Initialize(); };
        FormClosed += delegate { timer.Stop(); timer.Dispose(); browser.Dispose(); };
    }
    private async Task Initialize()
    {
        try
        {
            var environment = await CoreWebView2Environment.CreateAsync(null, Path.Combine(dataDir, "BrowserProfile"));
            await browser.EnsureCoreWebView2Async(environment);
            browser.CoreWebView2.Settings.IsPasswordAutosaveEnabled = false;
            browser.CoreWebView2.Settings.IsGeneralAutofillEnabled = false;
            browser.CoreWebView2.NavigationStarting += delegate(object sender, CoreWebView2NavigationStartingEventArgs e) {
                Uri target;
                if (!Uri.TryCreate(e.Uri, UriKind.Absolute, out target) || target.Scheme != "https") { e.Cancel = true; status.Text = "Only HTTPS navigation is allowed."; }
            };
            browser.CoreWebView2.SourceChanged += delegate { address.Text = browser.CoreWebView2.Source; };
            browser.CoreWebView2.NewWindowRequested += delegate(object sender, CoreWebView2NewWindowRequestedEventArgs e) {
                e.Handled = true;
                Uri target;
                if (Uri.TryCreate(e.Uri, UriKind.Absolute, out target) && target.Scheme == "https") Process.Start(new ProcessStartInfo(target.AbsoluteUri) { UseShellExecute = true });
            };
            browser.CoreWebView2.Navigate(initialUrl); timer.Start();
        }
        catch
        {
            status.Text = "The login browser could not start. Use your normal browser, or install Microsoft Edge WebView2 Runtime.";
            var normal = new Button { Text = "Open in normal browser", Dock = DockStyle.Bottom, Height = 40 };
            normal.Click += delegate { Process.Start(new ProcessStartInfo(initialUrl) { UseShellExecute = true }); };
            Controls.Add(normal); normal.BringToFront();
        }
    }
    internal static bool IsTrusted(Uri uri, string provider)
    {
        return (provider == "login.hva.nl" || provider == "login.uva.nl") && uri.Scheme == "https" && uri.Port == 443 &&
            uri.Host.Equals(provider, StringComparison.OrdinalIgnoreCase) && uri.AbsolutePath.StartsWith("/adfs/ls/", StringComparison.OrdinalIgnoreCase);
    }
    internal static string AutofillScript(string provider, string idValue, string passwordValue)
    {
        var serializer = new JavaScriptSerializer();
        return "(() => { if(location.protocol!=='https:' || location.hostname!==" + serializer.Serialize(provider) +
            " || (location.port && location.port!=='443') || !location.pathname.toLowerCase().startsWith('/adfs/ls/')) return 'wrong-site';" +
            "const id=document.getElementById('userNameInput'),pw=document.getElementById('passwordInput'),submit=document.getElementById('submitButton');" +
            "if(!id||!pw||!submit||pw.type!=='password'||!id.getClientRects().length||!pw.getClientRects().length) return 'not-ready';" +
            "const error=document.getElementById('errorText'); if(error && error.textContent.trim()) return 'error';" +
            "id.value=" + serializer.Serialize(idValue) + "; pw.value=" + serializer.Serialize(passwordValue) + ";" +
            "for(const field of [id,pw]){field.dispatchEvent(new Event('input',{bubbles:true}));field.dispatchEvent(new Event('change',{bubbles:true}));}" +
            "submit.click();return 'submitted';})()";
    }
    private async Task TryLogin()
    {
        if (busy || submitted || browser.CoreWebView2 == null) return;
        busy = true;
        try
        {
            string settingsPath = Path.Combine(dataDir, "settings.json");
            if (!File.Exists(settingsPath)) return;
            var settings = json.Deserialize<Dictionary<string,object>>(File.ReadAllText(settingsPath));
            object enabled, providerValue;
            if (!settings.TryGetValue("autoLoginEnabled", out enabled) || !Convert.ToBoolean(enabled)) { status.Text = "Autofill is off. Sign in manually."; return; }
            if (!settings.TryGetValue("loginProvider", out providerValue)) return;
            string provider = Convert.ToString(providerValue);
            Uri current;
            if (!Uri.TryCreate(browser.CoreWebView2.Source, UriKind.Absolute, out current) || !IsTrusted(current, provider)) return;
            string loginPath = Path.Combine(dataDir, "login.bin");
            if (!File.Exists(loginPath)) { status.Text = "No saved login. Sign in manually."; return; }
            byte[] clear = ProtectedData.Unprotect(File.ReadAllBytes(loginPath), null, DataProtectionScope.CurrentUser);
            Dictionary<string,string> credentials;
            try { credentials = json.Deserialize<Dictionary<string,string>>(Encoding.UTF8.GetString(clear)); }
            finally { Array.Clear(clear, 0, clear.Length); }
            if (string.IsNullOrEmpty(credentials["id"]) || string.IsNullOrEmpty(credentials["password"])) return;
            // Recheck origin in the page itself, since navigation can occur across the await boundary.
            string script = AutofillScript(provider, credentials["id"], credentials["password"]);
            credentials.Clear();
            string result = await browser.CoreWebView2.ExecuteScriptAsync(script);
            script = null;
            if (result == "\"submitted\"") { submitted = true; status.Text = "Login submitted once. Complete phone verification if requested. If sign-in fails, correct it manually or update Settings."; }
            else if (result == "\"error\"") { submitted = true; status.Text = "School reported a login error. Automatic retries stopped; check your details manually."; }
        }
        catch { submitted = true; status.Text = "Autofill could not run. Sign in manually or update your saved login in Settings."; }
        finally { busy = false; }
    }
}
