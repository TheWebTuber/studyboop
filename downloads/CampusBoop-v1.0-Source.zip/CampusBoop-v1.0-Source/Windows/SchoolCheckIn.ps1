param([switch]$Background)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class SchoolWindow {
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
}
'@
[System.Windows.Forms.Application]::EnableVisualStyles()
$mutex = New-Object System.Threading.Mutex($false, 'Local\SchoolCheckInHelper')
if (-not $mutex.WaitOne(0)) {
    if (-not $Background) { [IO.File]::WriteAllText((Join-Path $env:LOCALAPPDATA 'SchoolCheckInHelper\open-request'), 'open') }
    $mutex.Dispose(); exit
}
$script:dataDir = Join-Path $env:LOCALAPPDATA 'SchoolCheckInHelper'
[IO.Directory]::CreateDirectory($script:dataDir) | Out-Null
$script:configPath = Join-Path $script:dataDir 'settings.json'
$script:statePath = Join-Path $script:dataDir 'state.json'
. (Join-Path $PSScriptRoot 'Preferences.ps1')
$script:config = [pscustomobject]@{
    loginUrl = 'https://dlo.mijnhva.nl/d2l/home'
    checkinUrl = 'https://dlo.mijnhva.nl/d2l/le/lessons/762152/topics/2936746'
    option1Name = 'Check-in 1'; option1Url = ''
    option2Name = 'Check-in 2'; option2Url = ''
    cooldownMinutes = 60
    reminderMinutes = 45; backgroundEnabled = $true; onboardingComplete = $false
    autoLoginEnabled = $false; loginProvider = 'login.hva.nl'
    scheduleEnabled = $false; weeklySchedule = @(New-WeekSchedule)
}
function Save-Config { $script:config | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $script:configPath -Encoding UTF8 }
if (Test-Path -LiteralPath $script:configPath) {
    try {
        $saved = Get-Content -LiteralPath $script:configPath -Raw | ConvertFrom-Json
        foreach ($p in $script:config.PSObject.Properties) {
            if ($saved.PSObject.Properties.Name -contains $p.Name) { $p.Value = $saved.($p.Name) }
        }
    } catch { }
}
$script:doneDate = ''
$script:checkoutDate = ''
if (Test-Path -LiteralPath $script:statePath) {
    try {
        $state = Get-Content -LiteralPath $script:statePath -Raw | ConvertFrom-Json
        $script:doneDate = $state.doneDate
        if ($state.PSObject.Properties.Name -contains 'checkoutDate') { $script:checkoutDate = $state.checkoutDate }
    } catch { }
}
$script:nextReminder = [datetime]::MinValue
$script:nextCommitReminder = (Get-Date).AddMinutes([int]$script:config.reminderMinutes)
$script:lastNotification = 'checkin'
$script:commitDialog = $null
$script:breakUntil = [datetime]::MinValue
$script:paused = $false
$script:dialog = $null
$script:checkoutDialog = $null
$script:hadCodeWindow = $false
function Save-State {
    @{ doneDate = $script:doneDate; checkoutDate = $script:checkoutDate } | ConvertTo-Json | Set-Content -LiteralPath $script:statePath -Encoding UTF8
}
function Show-Centered($form) {
    Set-BrandTheme $form
    $form.TopMost = $true
    $form.Show(); $form.Activate(); $form.BringToFront(); $form.TopMost = $false
}
function Set-BrandTheme($form) {
    if ($form.Tag -eq 'branded') { return }
    $form.Tag = 'branded'
    $form.FormBorderStyle = 'Sizable'; $form.MaximizeBox = $true; $form.MinimizeBox = $true
    $iconPath = Join-Path $PSScriptRoot 'assets\creatorpromote.ico'
    if (Test-Path -LiteralPath $iconPath) { $form.Icon = New-Object Drawing.Icon($iconPath) }
    $form.Font = New-Object Drawing.Font('Segoe UI',9)
    $form.BackColor = [Drawing.ColorTranslator]::FromHtml('#F4F3FA')
    $form.ForeColor = [Drawing.ColorTranslator]::FromHtml('#241D3A')
    $form.ClientSize = New-Object Drawing.Size($form.ClientSize.Width,($form.ClientSize.Height + 112))
    $form.MinimumSize = New-Object Drawing.Size(($form.ClientSize.Width + 16),($form.ClientSize.Height + 39))
    foreach ($control in $form.Controls) {
        if (($control.Anchor -band [Windows.Forms.AnchorStyles]::Bottom) -ne 0) {
            if (($control.Anchor -band [Windows.Forms.AnchorStyles]::Top) -ne 0) { $control.Height -= 112; $control.Top += 112 }
        } else { $control.Top += 112 }
        if ($control -is [Windows.Forms.Button]) {
            $control.FlatStyle = 'Flat'
            $control.FlatAppearance.BorderColor = [Drawing.ColorTranslator]::FromHtml('#CEC9E2')
            $control.BackColor = [Drawing.Color]::White
            $control.Cursor = [Windows.Forms.Cursors]::Hand
            if ($control.Text -eq 'Already checked in today' -or $control.Text -eq 'Save') {
                $control.BackColor = [Drawing.ColorTranslator]::FromHtml('#25167A')
                $control.ForeColor = [Drawing.Color]::White
            }
        }
    }
    $header = New-Object Windows.Forms.Panel
    $header.Anchor = 'Top,Left,Right'
    $header.Location = New-Object Drawing.Point(0,0)
    $header.Size = New-Object Drawing.Size($form.ClientSize.Width,102)
    $header.BackColor = [Drawing.Color]::White
    $form.Controls.Add($header)
    $x = 20
    foreach ($name in @('hva','uva')) {
        $path = Join-Path $PSScriptRoot ('assets\' + $name + '.png')
        if (Test-Path -LiteralPath $path) {
            $picture = New-Object Windows.Forms.PictureBox
            $picture.Location = New-Object Drawing.Point($x,16)
            $picture.Size = New-Object Drawing.Size(200,40)
            $picture.SizeMode = 'Zoom'
            $picture.Image = [Drawing.Image]::FromFile($path)
            $header.Controls.Add($picture)
        }
        $x += 220
    }
    $title = New-Object Windows.Forms.Label
    $title.Text = 'CampusBoop v1.0  /  Meet Boop, your study reminder'
    $title.Font = New-Object Drawing.Font('Segoe UI',10,[Drawing.FontStyle]::Bold)
    $title.ForeColor = [Drawing.ColorTranslator]::FromHtml('#25167A')
    $title.Location = New-Object Drawing.Point(20,73)
    $title.Size = New-Object Drawing.Size(($form.ClientSize.Width - 40),24)
    $header.Controls.Add($title)
    $form.Add_FormClosed({
        param($sender,$eventArgs)
        foreach ($panel in $sender.Controls) {
            foreach ($child in $panel.Controls) {
                if ($child -is [Windows.Forms.PictureBox] -and $child.Image) { $child.Image.Dispose() }
            }
        }
    })
}
function Open-Link([string]$url) {
    $uri = $null
    if (-not [Uri]::TryCreate($url, [UriKind]::Absolute, [ref]$uri) -or $uri.Scheme -ne 'https') {
        [System.Windows.Forms.MessageBox]::Show('Enter a valid HTTPS link in Settings.', 'CampusBoop') | Out-Null
        return
    }
    if ($script:config.autoLoginEnabled -and (Test-Path -LiteralPath (Join-Path $script:dataDir 'login.bin'))) {
        Start-Process -FilePath (Join-Path $PSScriptRoot 'SchoolLogin.exe') -ArgumentList @('--url', ('"' + $uri.AbsoluteUri + '"'))
    } else { Start-Process -FilePath $uri.AbsoluteUri }
}
function New-Button($form, [string]$text, [int]$top, $action) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $text; $b.Location = New-Object Drawing.Point(20,$top)
    $b.Size = New-Object Drawing.Size(420,34)
    $b.Anchor = 'Top,Left,Right'
    $b.Add_Click($action); $form.Controls.Add($b)
}
function Set-CheckedIn {
    $script:doneDate = (Get-Date).ToString('yyyy-MM-dd')
    $script:checkoutDate = ''; Save-State
    if ($script:dialog -and -not $script:dialog.IsDisposed) { $script:dialog.Close() }
}
function Set-CheckedOut {
    $script:checkoutDate = (Get-Date).ToString('yyyy-MM-dd'); Save-State
    foreach ($form in @($script:dialog,$script:commitDialog,$script:checkoutDialog)) {
        if ($form -and -not $form.IsDisposed) { $form.Close() }
    }
}
function Show-Checkout {
    if ($script:checkoutDialog -and -not $script:checkoutDialog.IsDisposed) { $script:checkoutDialog.Activate(); return }
    $f = New-Object System.Windows.Forms.Form
    $script:checkoutDialog = $f
    $f.Text = 'Boop - finished for today?'; $f.ClientSize = New-Object Drawing.Size(460,225)
    $f.StartPosition = 'CenterScreen'; $f.FormBorderStyle = 'FixedDialog'; $f.MaximizeBox = $false
    $label = New-Object System.Windows.Forms.Label
    $label.Text = "Don't forget to commit or push your work.`r`nFinished today? You can stop both reminders here."
    $label.Location = New-Object Drawing.Point(20,20); $label.Size = New-Object Drawing.Size(420,55)
    $f.Controls.Add($label)
    New-Button $f 'Checked out for today - stop all reminders' 90 { Set-CheckedOut }
    New-Button $f 'Still working - keep reminders' 140 { $script:checkoutDialog.Close() }
    Show-Centered $f
}
function Start-Break {
    $script:breakUntil = (Get-Date).AddMinutes(10)
    $script:nextCommitReminder = $script:breakUntil.AddMinutes([int]$script:config.reminderMinutes)
    foreach ($form in @($script:commitDialog,$script:checkoutDialog)) {
        if ($form -and -not $form.IsDisposed) { $form.Close() }
    }
}
function Resume-Work {
    $script:breakUntil = [datetime]::MinValue
    $script:nextCommitReminder = (Get-Date).AddMinutes([int]$script:config.reminderMinutes)
}
function Show-CommitReminder {
    if ($script:commitDialog -and -not $script:commitDialog.IsDisposed) { $script:commitDialog.Activate(); return }
    $f = New-Object System.Windows.Forms.Form
    $script:commitDialog = $f
    $f.Text = 'Boop - save your work and take a breather'; $f.ClientSize = New-Object Drawing.Size(460,290)
    $f.StartPosition = 'CenterScreen'
    $label = New-Object System.Windows.Forms.Label
    $label.Text = "Hey, Boop here! Don't forget to commit or push your work.`r`nKeep your work hours and commits safe.`r`n`r`nReminder: take a break once in a while. Stretch, grab water, or step away for a moment."
    $label.Location = New-Object Drawing.Point(20,18); $label.Size = New-Object Drawing.Size(420,112)
    $label.Anchor = 'Top,Left,Right'; $f.Controls.Add($label)
    New-Button $f 'Got it - thanks, Boop' 145 { $script:commitDialog.Close() }
    New-Button $f 'Keep working' 190 { $script:commitDialog.Close() }
    New-Button $f 'Take a break - quiet for 10 minutes' 235 { Start-Break }
    $f.Add_FormClosed({ $script:nextCommitReminder = (Get-Date).AddMinutes([int]$script:config.reminderMinutes); if ($script:breakUntil -gt (Get-Date)) { $script:nextCommitReminder = $script:breakUntil.AddMinutes([int]$script:config.reminderMinutes) } })
    Show-Centered $f
}
function Show-Checkin {
    if ($script:dialog -and -not $script:dialog.IsDisposed) { $script:dialog.Activate(); return }
    $f = New-Object System.Windows.Forms.Form
    $script:dialog = $f
    $f.Text = 'CampusBoop v1.0'; $f.ClientSize = New-Object Drawing.Size(460,475)
    $f.StartPosition = 'CenterScreen'; $f.FormBorderStyle = 'FixedDialog'; $f.MaximizeBox = $false
    $label = New-Object System.Windows.Forms.Label
    $label.Text = "Working on school in VS Code?`r`nLog in, choose your check-in, and describe your work."
    $label.Location = New-Object Drawing.Point(20,18); $label.Size = New-Object Drawing.Size(420,48)
    $f.Controls.Add($label)
    New-Button $f 'Already checked in today' 76 { Set-CheckedIn }
    New-Button $f '1. Open school login' 120 { Open-Link $script:config.loginUrl }
    New-Button $f ('2. Open ' + $script:config.option1Name) 164 {
        $url = $script:config.option1Url
        if ([string]::IsNullOrWhiteSpace($url)) { $url = $script:config.checkinUrl }
        Open-Link $url
    }
    New-Button $f ('2. Open ' + $script:config.option2Name) 208 {
        $url = $script:config.option2Url
        if ([string]::IsNullOrWhiteSpace($url)) { $url = $script:config.checkinUrl }
        Open-Link $url
    }
    New-Button $f 'Remind me in 15 minutes' 252 {
        $script:nextReminder = (Get-Date).AddMinutes(15); $script:dialog.Close()
    }
    New-Button $f 'Checked out for today - stop all reminders' 296 { Set-CheckedOut }
    $status = New-Object System.Windows.Forms.Label
    $status.Text = 'Checking in keeps commit reminders on. Checking out stops both.'
    $status.Location = New-Object Drawing.Point(20,346); $status.Size = New-Object Drawing.Size(420,38)
    $f.Controls.Add($status)
    New-Button $f 'Settings / personal preferences' 391 { Show-Settings }
    New-Button $f 'Resume work after a break' 433 { Resume-Work }
    $f.Add_FormClosed({ if ($script:nextReminder -lt (Get-Date)) { $script:nextReminder = (Get-Date).AddMinutes([int]$script:config.cooldownMinutes) }; if (-not $script:config.backgroundEnabled) { [Windows.Forms.Application]::ExitThread() } })
    Show-Centered $f
}
$script:tray = New-Object System.Windows.Forms.NotifyIcon
$script:tray.Icon = New-Object Drawing.Icon((Join-Path $PSScriptRoot 'assets\creatorpromote.ico'))
$script:tray.Text = 'CampusBoop'; $script:tray.Visible = $true
$menu = New-Object System.Windows.Forms.ContextMenuStrip
function Add-Menu([string]$name, $action) {
    $item = $menu.Items.Add($name); $item.Add_Click($action); return $item
}
$null = Add-Menu 'Open CampusBoop' { Show-Checkin }
$null = Add-Menu 'Already checked in today' { Set-CheckedIn }
$null = Add-Menu 'Checked out for today - stop all reminders' { Set-CheckedOut }
$null = Add-Menu 'Boop: commit and break reminder' { Show-CommitReminder }
$null = Add-Menu 'Settings / classmate links' { Show-Settings }
$null = Add-Menu 'Enable reminders again today' {
    $script:doneDate = ''; $script:checkoutDate = ''; $script:nextReminder = [datetime]::MinValue
    $script:nextCommitReminder = (Get-Date).AddMinutes([int]$script:config.reminderMinutes); Save-State
}
$pauseItem = Add-Menu 'Pause reminders' { $script:paused = -not $script:paused; $pauseItem.Checked = $script:paused }
$null = Add-Menu 'Background / Windows startup settings' { Show-Settings }
$null = Add-Menu 'Take a 10-minute break' { Start-Break }
$null = Add-Menu 'Resume work' { Resume-Work }
$null = Add-Menu 'Exit' { [Windows.Forms.Application]::ExitThread() }
$script:tray.ContextMenuStrip = $menu
$script:tray.Add_DoubleClick({ Show-Checkin })
$script:tray.Add_BalloonTipClicked({
    if ($script:lastNotification -eq 'commit') { Show-CommitReminder } else { Show-Checkin }
})
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 2000
$timer.Add_Tick({
    $now = Get-Date
    $request = Join-Path $script:dataDir 'open-request'
    if (Test-Path -LiteralPath $request) { Remove-Item -LiteralPath $request; Show-Checkin }
    $codeWindows = @(Get-Process -Name 'Code','Code - Insiders' -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 })
    $hasCodeWindow = $codeWindows.Count -gt 0
    $codeJustClosed = $script:hadCodeWindow -and -not $hasCodeWindow
    $script:hadCodeWindow = $hasCodeWindow
    if ($script:paused -or $script:checkoutDate -eq $now.ToString('yyyy-MM-dd')) { return }
    if ($now -lt $script:breakUntil) { return }
    if (-not (Test-AlarmTime $now)) { return }
    if ($codeJustClosed) { Show-Checkout; return }
    if (-not $hasCodeWindow) { return }
    [uint32]$foregroundPid = 0
    $null = [SchoolWindow]::GetWindowThreadProcessId([SchoolWindow]::GetForegroundWindow(), [ref]$foregroundPid)
    if ($foregroundPid -eq 0) { return }
    $process = Get-Process -Id $foregroundPid -ErrorAction SilentlyContinue
    if ($process -and $process.ProcessName -in @('Code','Code - Insiders')) {
        if ($script:commitDialog -and -not $script:commitDialog.IsDisposed) { return }
        if ($script:dialog -and -not $script:dialog.IsDisposed) { return }
        if ($now -ge $script:nextCommitReminder) {
            $script:nextCommitReminder = $now.AddMinutes([int]$script:config.reminderMinutes)
            $script:lastNotification = 'commit'
            Show-CommitReminder
        } elseif ($script:doneDate -ne $now.ToString('yyyy-MM-dd') -and $now -ge $script:nextReminder) {
            $script:nextReminder = $now.AddMinutes([int]$script:config.cooldownMinutes)
            $script:lastNotification = 'checkin'
            Show-Checkin
        }
    }
})
try {
    if (-not $script:config.onboardingComplete) {
        if (-not (Show-FirstRun)) { return }
    }
    if (Test-StartupEnabled) { Set-StartupEnabled $true }
    Save-Config
    $timer.Start()
    if (-not $Background -or -not $script:config.backgroundEnabled) { Show-Checkin }
    [Windows.Forms.Application]::Run()
} finally {
    $timer.Stop(); $timer.Dispose(); $script:tray.Visible = $false; $script:tray.Dispose()
    $mutex.ReleaseMutex(); $mutex.Dispose()
}


