CampusBoop v1.1.1 - Windows x64
================================

NEW USER START
1. Extract this ZIP completely.
2. Open CampusBoop\CampusBoop.exe.
3. Complete the Welcome setup. You can optionally save your school login for trusted HvA/UvA autofill.
4. Change school/project links in Settings if needed.

This package contains NO user settings, saved login, reminder state or browser profile.
CampusBoop creates those only after the new user starts it.

CampusBoop is an independent student-made project and is not made, endorsed or supported by HvA or UvA.

WINDOWS NOTE
Because this public test release is unsigned, Windows may show an initial SmartScreen / unknown-publisher warning when the downloaded app is first started. The working Quiet design removes Internet-zone markers after the app is allowed to run and builds its trusted school-browser helper locally on first use, which avoids repeated downloaded-app warnings during normal button/login use.
