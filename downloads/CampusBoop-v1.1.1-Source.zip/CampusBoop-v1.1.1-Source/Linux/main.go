package main

import (
	"embed"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"
)

const version = "1.1.1"

//go:embed ui.html assets/*
var content embed.FS

type DayRule struct {
	Day     string `json:"day"`
	Enabled bool   `json:"enabled"`
	Start   string `json:"start"`
	End     string `json:"end"`
}

type Config struct {
	LoginURL                string    `json:"loginUrl"`
	CheckinURL              string    `json:"checkinUrl"`
	Option1Name             string    `json:"option1Name"`
	Option1URL              string    `json:"option1Url"`
	Option2Name             string    `json:"option2Name"`
	Option2URL              string    `json:"option2Url"`
	Tool1Name               string    `json:"tool1Name"`
	Tool1URL                string    `json:"tool1Url"`
	Tool2Name               string    `json:"tool2Name"`
	Tool2URL                string    `json:"tool2Url"`
	Tool3Name               string    `json:"tool3Name"`
	Tool3URL                string    `json:"tool3Url"`
	SchoolProvider          string    `json:"schoolProvider"`
	CooldownMinutes         int       `json:"cooldownMinutes"`
	ReminderMinutes         int       `json:"reminderMinutes"`
	BackgroundEnabled       bool      `json:"backgroundEnabled"`
	SmartReminderEnabled    bool      `json:"smartReminderEnabled"`
	StartupReminderEnabled  bool      `json:"startupReminderEnabled"`
	CheckoutReminderEnabled bool      `json:"checkoutReminderEnabled"`
	StartupDelayMinutes     int       `json:"startupDelayMinutes"`
	TypicalFinishTime       string    `json:"typicalFinishTime"`
	OnboardingComplete      bool      `json:"onboardingComplete"`
	ScheduleEnabled         bool      `json:"scheduleEnabled"`
	WeeklySchedule          []DayRule `json:"weeklySchedule"`
}

type State struct {
	DoneDate                      string `json:"doneDate"`
	CheckoutDate                  string `json:"checkoutDate"`
	ScheduledCheckoutReminderDate string `json:"scheduledCheckoutReminderDate"`
}

type Runtime struct {
	Paused               bool      `json:"paused"`
	BreakUntil           time.Time `json:"breakUntil"`
	NextReminder         time.Time `json:"nextReminder"`
	NextCommitReminder   time.Time `json:"nextCommitReminder"`
	HadCodeWindow        bool      `json:"hadCodeWindow"`
	StartupReminderAt    time.Time `json:"startupReminderAt"`
	StartupReminderShown bool      `json:"startupReminderShown"`
}

type App struct {
	mu         sync.Mutex
	cfg        Config
	state      State
	rt         Runtime
	dataDir    string
	configPath string
	statePath  string
	portPath   string
	exePath    string
	server     *http.Server
	listener   net.Listener
	done       chan struct{}
}

func defaultSchedule() []DayRule {
	days := []string{"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"}
	out := make([]DayRule, 0, len(days))
	for _, d := range days {
		out = append(out, DayRule{Day: d, Enabled: false, Start: "09:00", End: "17:00"})
	}
	return out
}

func schoolDefaults(school string) (login, t1n, t1u, t2n, t2u, t3n, t3u string) {
	if school == "uva" {
		return "https://student.uva.nl/", "Print", "https://uva.mycampusprint.nl/Login/Login", "Top up", "https://uva-hva.mynetpay.nl/Auth/Login", "Library", "https://lib.uva.nl"
	}
	return "https://dlo.mijnhva.nl/d2l/home", "Print", "https://hva.mycampusprint.nl/Login/Login", "Top up", "https://uva-hva.mynetpay.nl/Auth/Login", "Library", "https://lib.hva.nl"
}

func applySchoolDefaults(c *Config, school string, setLogin bool) {
	if school != "uva" {
		school = "hva"
	}
	c.SchoolProvider = school
	login, n1, u1, n2, u2, n3, u3 := schoolDefaults(school)
	if setLogin {
		c.LoginURL = login
	}
	c.Tool1Name, c.Tool1URL = n1, u1
	c.Tool2Name, c.Tool2URL = n2, u2
	c.Tool3Name, c.Tool3URL = n3, u3
}

func defaultConfig() Config {
	c := Config{
		LoginURL:    "https://dlo.mijnhva.nl/d2l/home",
		CheckinURL:  "https://dlo.mijnhva.nl/d2l/le/lessons/762152/topics/2936746",
		Option1Name: "Check-in 1", Option2Name: "Check-in 2",
		SchoolProvider: "hva", CooldownMinutes: 60, ReminderMinutes: 45,
		BackgroundEnabled: true, SmartReminderEnabled: true, StartupReminderEnabled: true,
		CheckoutReminderEnabled: true, StartupDelayMinutes: 2, TypicalFinishTime: "17:00",
		OnboardingComplete: false, ScheduleEnabled: false, WeeklySchedule: defaultSchedule(),
	}
	applySchoolDefaults(&c, "hva", false)
	return c
}

func configHome() (string, error) {
	if x := os.Getenv("XDG_CONFIG_HOME"); x != "" {
		return filepath.Join(x, "campusboop"), nil
	}
	h, err := os.UserHomeDir()
	if err != nil {
		return "", err
	}
	return filepath.Join(h, ".config", "campusboop"), nil
}

func newApp() (*App, error) {
	d, err := configHome()
	if err != nil {
		return nil, err
	}
	if err := os.MkdirAll(d, 0700); err != nil {
		return nil, err
	}
	exe, _ := os.Executable()
	exe, _ = filepath.Abs(exe)
	a := &App{dataDir: d, configPath: filepath.Join(d, "settings.json"), statePath: filepath.Join(d, "state.json"), portPath: filepath.Join(d, "port"), exePath: exe, done: make(chan struct{})}
	a.cfg = defaultConfig()
	_ = readJSON(a.configPath, &a.cfg)
	_ = readJSON(a.statePath, &a.state)
	if len(a.cfg.WeeklySchedule) != 7 {
		a.cfg.WeeklySchedule = defaultSchedule()
	}
	if a.cfg.SchoolProvider != "uva" {
		a.cfg.SchoolProvider = "hva"
	}
	if a.cfg.StartupDelayMinutes < 1 || a.cfg.StartupDelayMinutes > 60 {
		a.cfg.StartupDelayMinutes = 2
	}
	if a.cfg.CooldownMinutes < 1 || a.cfg.CooldownMinutes > 1440 {
		a.cfg.CooldownMinutes = 60
	}
	if a.cfg.ReminderMinutes < 1 || a.cfg.ReminderMinutes > 1440 {
		a.cfg.ReminderMinutes = 45
	}
	if _, ok := clockMinutes(a.cfg.TypicalFinishTime); !ok {
		a.cfg.TypicalFinishTime = "17:00"
	}
	if strings.TrimSpace(a.cfg.Tool1Name) == "" || strings.TrimSpace(a.cfg.Tool1URL) == "" || strings.TrimSpace(a.cfg.Tool2Name) == "" || strings.TrimSpace(a.cfg.Tool2URL) == "" || strings.TrimSpace(a.cfg.Tool3Name) == "" || strings.TrimSpace(a.cfg.Tool3URL) == "" {
		applySchoolDefaults(&a.cfg, a.cfg.SchoolProvider, false)
	}
	now := time.Now()
	a.rt.NextReminder = now
	a.rt.NextCommitReminder = now.Add(time.Duration(a.cfg.ReminderMinutes) * time.Minute)
	return a, nil
}

func readJSON(path string, v any) error {
	b, e := os.ReadFile(path)
	if e != nil {
		return e
	}
	return json.Unmarshal(b, v)
}
func writeJSON(path string, v any) error {
	b, e := json.MarshalIndent(v, "", "  ")
	if e != nil {
		return e
	}
	return os.WriteFile(path, b, 0600)
}
func (a *App) saveConfig() { _ = writeJSON(a.configPath, a.cfg) }
func (a *App) saveState()  { _ = writeJSON(a.statePath, a.state) }

func schoolDayKey(t time.Time) string {
	if t.Hour() < 4 {
		t = t.AddDate(0, 0, -1)
	}
	return t.Format("2006-01-02")
}

func (a *App) uiURL(mode string) string {
	port := ""
	if a.listener != nil {
		_, p, _ := net.SplitHostPort(a.listener.Addr().String())
		port = p
	}
	u := "http://127.0.0.1:" + port + "/"
	if mode != "" {
		u += "?mode=" + mode
	}
	return u
}
func openBrowser(url string) error { return exec.Command("xdg-open", url).Start() }
func notify(title, body string) {
	if _, e := exec.LookPath("notify-send"); e == nil {
		_ = exec.Command("notify-send", "--app-name=CampusBoop", title, body).Start()
	}
}
func (a *App) openExternal(url string) error {
	if !strings.HasPrefix(strings.ToLower(strings.TrimSpace(url)), "https://") {
		return errors.New("this link is not configured yet or is not HTTPS")
	}
	return openBrowser(url)
}

func (a *App) autostartPath() string {
	return filepath.Join(filepath.Dir(a.dataDir), "autostart", "CampusBoop.desktop")
}
func (a *App) setAutostart(on bool) error {
	p := a.autostartPath()
	if !on {
		if e := os.Remove(p); e != nil && !os.IsNotExist(e) {
			return e
		}
		return nil
	}
	if e := os.MkdirAll(filepath.Dir(p), 0755); e != nil {
		return e
	}
	text := fmt.Sprintf("[Desktop Entry]\nType=Application\nName=CampusBoop\nComment=Student check-in, commit, break and checkout reminder\nExec=%s --background\nTerminal=false\nX-GNOME-Autostart-enabled=true\n", shellEscapeDesktop(a.exePath))
	return os.WriteFile(p, []byte(text), 0644)
}
func shellEscapeDesktop(s string) string {
	if strings.ContainsAny(s, " \t\"") {
		return "\"" + strings.ReplaceAll(s, "\"", "\\\"") + "\""
	}
	return s
}
func (a *App) autostartEnabled() bool { _, e := os.Stat(a.autostartPath()); return e == nil }

func (a *App) statusPayload() map[string]any {
	a.mu.Lock()
	defer a.mu.Unlock()
	key := schoolDayKey(time.Now())
	return map[string]any{"version": version, "config": a.cfg, "state": a.state, "paused": a.rt.Paused, "breakUntil": a.rt.BreakUntil, "autostart": a.autostartEnabled(), "checkedInToday": a.state.DoneDate == key, "checkedOutToday": a.state.CheckoutDate == key}
}

func (a *App) handleAPI(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	if r.Method == http.MethodGet {
		_ = json.NewEncoder(w).Encode(a.statusPayload())
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", 405)
		return
	}
	var req map[string]any
	if e := json.NewDecoder(io.LimitReader(r.Body, 1<<20)).Decode(&req); e != nil {
		http.Error(w, "bad request", 400)
		return
	}
	action, _ := req["action"].(string)
	var err error
	a.mu.Lock()
	now := time.Now()
	key := schoolDayKey(now)
	switch action {
	case "checked-in":
		a.state.DoneDate = key
		a.state.CheckoutDate = ""
		a.state.ScheduledCheckoutReminderDate = ""
		a.rt.NextCommitReminder = now.Add(time.Duration(a.cfg.ReminderMinutes) * time.Minute)
		a.saveState()
	case "checked-out":
		a.state.CheckoutDate = key
		a.saveState()
	case "remind-15":
		a.rt.NextReminder = now.Add(15 * time.Minute)
	case "break-10":
		a.rt.BreakUntil = now.Add(10 * time.Minute)
		a.rt.NextCommitReminder = a.rt.BreakUntil.Add(time.Duration(a.cfg.ReminderMinutes) * time.Minute)
	case "resume":
		a.rt.BreakUntil = time.Time{}
		a.rt.NextCommitReminder = now.Add(time.Duration(a.cfg.ReminderMinutes) * time.Minute)
	case "toggle-pause":
		a.rt.Paused = !a.rt.Paused
	case "enable-today":
		a.state = State{}
		a.rt.NextReminder = now
		a.rt.NextCommitReminder = now.Add(time.Duration(a.cfg.ReminderMinutes) * time.Minute)
		a.saveState()
	case "open-login":
		err = a.openExternal(a.cfg.LoginURL)
	case "open-option1":
		u := a.cfg.Option1URL
		if strings.TrimSpace(u) == "" {
			u = a.cfg.CheckinURL
		}
		err = a.openExternal(u)
	case "open-option2":
		u := a.cfg.Option2URL
		if strings.TrimSpace(u) == "" {
			u = a.cfg.CheckinURL
		}
		err = a.openExternal(u)
	case "open-tool1":
		err = a.openExternal(a.cfg.Tool1URL)
	case "open-tool2":
		err = a.openExternal(a.cfg.Tool2URL)
	case "open-tool3":
		err = a.openExternal(a.cfg.Tool3URL)
	case "complete-onboarding":
		school, _ := req["schoolProvider"].(string)
		if school != "uva" {
			school = "hva"
		}
		applySchoolDefaults(&a.cfg, school, true)
		if v, ok := req["smartReminderEnabled"].(bool); ok {
			a.cfg.SmartReminderEnabled = v
		}
		if v, ok := req["startupReminderEnabled"].(bool); ok {
			a.cfg.StartupReminderEnabled = v
		}
		if v, ok := req["checkoutReminderEnabled"].(bool); ok {
			a.cfg.CheckoutReminderEnabled = v
		}
		if v, ok := req["startupDelayMinutes"].(float64); ok && int(v) >= 1 && int(v) <= 60 {
			a.cfg.StartupDelayMinutes = int(v)
		}
		if v, ok := req["backgroundEnabled"].(bool); ok {
			a.cfg.BackgroundEnabled = v
		}
		a.cfg.OnboardingComplete = true
		if v, ok := req["autostart"].(bool); ok {
			err = a.setAutostart(v)
		}
		a.saveConfig()
	case "save-settings":
		raw, ok := req["config"]
		if !ok {
			err = errors.New("missing config")
			break
		}
		b, _ := json.Marshal(raw)
		c := a.cfg
		if e := json.Unmarshal(b, &c); e != nil {
			err = e
			break
		}
		if c.CooldownMinutes < 1 || c.CooldownMinutes > 1440 || c.ReminderMinutes < 1 || c.ReminderMinutes > 1440 {
			err = errors.New("reminder intervals must be 1-1440 minutes")
			break
		}
		if c.StartupDelayMinutes < 1 || c.StartupDelayMinutes > 60 {
			err = errors.New("startup delay must be 1-60 minutes")
			break
		}
		if _, ok := clockMinutes(c.TypicalFinishTime); !ok {
			err = errors.New("typical finish time must be HH:MM")
			break
		}
		if c.SchoolProvider != "uva" {
			c.SchoolProvider = "hva"
		}
		if !httpsOrBlank(c.LoginURL, false) || !httpsOrBlank(c.CheckinURL, true) || !httpsOrBlank(c.Option1URL, true) || !httpsOrBlank(c.Option2URL, true) || !httpsOrBlank(c.Tool1URL, false) || !httpsOrBlank(c.Tool2URL, false) || !httpsOrBlank(c.Tool3URL, false) {
			err = errors.New("configured links must use HTTPS")
			break
		}
		if strings.TrimSpace(c.Tool1Name) == "" || strings.TrimSpace(c.Tool2Name) == "" || strings.TrimSpace(c.Tool3Name) == "" {
			err = errors.New("student tool names cannot be empty")
			break
		}
		if len(c.WeeklySchedule) != 7 {
			c.WeeklySchedule = defaultSchedule()
		}
		c.OnboardingComplete = true
		a.cfg = c
		a.rt.NextCommitReminder = now.Add(time.Duration(c.ReminderMinutes) * time.Minute)
		a.saveConfig()
	case "apply-school-defaults":
		school, _ := req["schoolProvider"].(string)
		applySchoolDefaults(&a.cfg, school, true)
		a.saveConfig()
	case "autostart-on":
		err = a.setAutostart(true)
	case "autostart-off":
		err = a.setAutostart(false)
	case "exit":
		go func() {
			time.Sleep(150 * time.Millisecond)
			_ = a.server.Close()
			select {
			case <-a.done:
			default:
				close(a.done)
			}
		}()
	default:
		err = errors.New("unknown action")
	}
	a.mu.Unlock()
	if err != nil {
		w.WriteHeader(400)
		_ = json.NewEncoder(w).Encode(map[string]any{"ok": false, "error": err.Error()})
		return
	}
	_ = json.NewEncoder(w).Encode(map[string]any{"ok": true})
}

func httpsOrBlank(s string, blank bool) bool {
	s = strings.TrimSpace(strings.ToLower(s))
	if s == "" {
		return blank
	}
	return strings.HasPrefix(s, "https://")
}
func clockMinutes(s string) (int, bool) {
	p := strings.Split(s, ":")
	if len(p) != 2 {
		return 0, false
	}
	h, e1 := strconv.Atoi(p[0])
	m, e2 := strconv.Atoi(p[1])
	if e1 != nil || e2 != nil || h < 0 || h > 23 || m < 0 || m > 59 {
		return 0, false
	}
	return h*60 + m, true
}

func (a *App) allowedNow(t time.Time) bool {
	if !a.cfg.ScheduleEnabled {
		return true
	}
	n := t.Hour()*60 + t.Minute()
	day := t.Weekday().String()
	prev := t.AddDate(0, 0, -1).Weekday().String()
	for _, r := range a.cfg.WeeklySchedule {
		if !r.Enabled {
			continue
		}
		sm, o1 := clockMinutes(r.Start)
		em, o2 := clockMinutes(r.End)
		if !o1 || !o2 || sm == em {
			continue
		}
		if r.Day == day {
			if sm < em && n >= sm && n < em {
				return true
			}
			if sm > em && n >= sm {
				return true
			}
		}
		if r.Day == prev && sm > em && n < em {
			return true
		}
	}
	return false
}

func (a *App) checkoutReminderDue(t time.Time, key string) bool {
	if !a.cfg.CheckoutReminderEnabled || a.state.DoneDate != key || a.state.CheckoutDate == key || a.state.ScheduledCheckoutReminderDate == key {
		return false
	}
	target := a.cfg.TypicalFinishTime
	if a.cfg.ScheduleEnabled {
		day := t.Weekday().String()
		for _, r := range a.cfg.WeeklySchedule {
			if r.Enabled && r.Day == day {
				if _, ok := clockMinutes(r.End); ok {
					target = r.End
				}
				break
			}
		}
	}
	mins, ok := clockMinutes(target)
	if !ok {
		return false
	}
	reminder := mins - 15
	if reminder < 0 {
		reminder += 24 * 60
	}
	now := t.Hour()*60 + t.Minute()
	return now >= reminder
}

func codeRunning() bool {
	entries, e := os.ReadDir("/proc")
	if e != nil {
		return false
	}
	for _, x := range entries {
		if !x.IsDir() {
			continue
		}
		if _, e := strconv.Atoi(x.Name()); e != nil {
			continue
		}
		b, e := os.ReadFile(filepath.Join("/proc", x.Name(), "comm"))
		if e != nil {
			continue
		}
		n := strings.TrimSpace(strings.ToLower(string(b)))
		if n == "code" || n == "code-insiders" {
			return true
		}
	}
	return false
}
func codeForeground() bool {
	if _, e := exec.LookPath("xdotool"); e != nil {
		return codeRunning()
	}
	out, e := exec.Command("sh", "-c", "xdotool getactivewindow getwindowpid 2>/dev/null").Output()
	if e != nil {
		return codeRunning()
	}
	pid := strings.TrimSpace(string(out))
	if pid == "" {
		return codeRunning()
	}
	b, e := os.ReadFile(filepath.Join("/proc", pid, "comm"))
	if e != nil {
		return codeRunning()
	}
	n := strings.TrimSpace(strings.ToLower(string(b)))
	return n == "code" || n == "code-insiders"
}

func (a *App) reminderLoop() {
	tick := time.NewTicker(2 * time.Second)
	defer tick.Stop()
	for range tick.C {
		a.mu.Lock()
		now := time.Now()
		key := schoolDayKey(now)
		hasCode := codeRunning()
		justClosed := a.rt.HadCodeWindow && !hasCode
		a.rt.HadCodeWindow = hasCode
		mode, title, body := "", "", ""
		if !a.rt.StartupReminderShown && a.cfg.StartupReminderEnabled && !a.rt.StartupReminderAt.IsZero() && !now.Before(a.rt.StartupReminderAt) {
			a.rt.StartupReminderShown = true
			if !a.rt.Paused && a.state.DoneDate != key && a.state.CheckoutDate != key {
				mode = "startup"
				title = "Boop — don't forget to check in"
				body = "Going to school today? CampusBoop is ready when you need it."
			}
		}
		if mode == "" && a.checkoutReminderDue(now, key) {
			a.state.ScheduledCheckoutReminderDate = key
			a.saveState()
			mode = "checkout"
			title = "Boop — time to check out?"
			body = "Your school day is nearly finished. Check out when you're done."
		}
		if mode == "" && (a.rt.Paused || a.state.CheckoutDate == key || (!a.rt.BreakUntil.IsZero() && now.Before(a.rt.BreakUntil)) || !a.allowedNow(now)) {
			a.mu.Unlock()
			continue
		}
		if mode == "" && justClosed && a.cfg.CheckoutReminderEnabled && a.state.DoneDate == key && a.state.CheckoutDate != key {
			mode = "checkout"
			title = "Boop — finished for today?"
			body = "Remember to commit or push, then check out if you're done."
		}
		if mode == "" && hasCode && codeForeground() {
			if a.state.DoneDate == key && !now.Before(a.rt.NextCommitReminder) {
				a.rt.NextCommitReminder = now.Add(time.Duration(a.cfg.ReminderMinutes) * time.Minute)
				mode = "commit"
				title = "Boop — save your work"
				body = "Commit or push your work, then take a quick break if you need one."
			} else if a.cfg.SmartReminderEnabled && a.state.DoneDate != key && !now.Before(a.rt.NextReminder) {
				a.rt.NextReminder = now.Add(time.Duration(a.cfg.CooldownMinutes) * time.Minute)
				mode = "checkin"
				title = "Boop — school check-in"
				body = "Open CampusBoop to complete your school check-in."
			}
		}
		a.mu.Unlock()
		if mode != "" {
			notify(title, body)
			_ = openBrowser(a.uiURL(mode))
		}
	}
}

func acquireLock(path string) (*os.File, error) {
	f, e := os.OpenFile(path, os.O_CREATE|os.O_RDWR, 0600)
	if e != nil {
		return nil, e
	}
	if e := syscall.Flock(int(f.Fd()), syscall.LOCK_EX|syscall.LOCK_NB); e != nil {
		f.Close()
		return nil, e
	}
	return f, nil
}
func openExisting(dataDir string) bool {
	b, e := os.ReadFile(filepath.Join(dataDir, "port"))
	if e != nil {
		return false
	}
	p := strings.TrimSpace(string(b))
	if p == "" {
		return false
	}
	_ = openBrowser("http://127.0.0.1:" + p + "/")
	return true
}
func printHelp() {
	fmt.Println("CampusBoop v" + version)
	fmt.Println("  campusboop                 Open CampusBoop")
	fmt.Println("  campusboop --background    Run quietly in the background")
	fmt.Println("  campusboop --autostart-on  Start CampusBoop when you sign in")
	fmt.Println("  campusboop --autostart-off Disable sign-in startup")
	fmt.Println("  campusboop --help          Show this help")
	fmt.Println("  campusboop --version       Show version")
	fmt.Println("  campusboop --uninstall     Remove CampusBoop (keep settings)")
	fmt.Println("  campusboop --purge         Remove CampusBoop and local settings")
	fmt.Println("Instructions: https://campusboop.creatorpromote.com/#instructions")
}

func main() {
	args := os.Args[1:]
	background := false
	for _, x := range args {
		switch x {
		case "--help", "-h":
			printHelp()
			return
		case "--version":
			fmt.Println(version)
			return
		case "--background":
			background = true
		}
	}
	app, e := newApp()
	if e != nil {
		fmt.Fprintln(os.Stderr, "CampusBoop:", e)
		os.Exit(1)
	}
	for _, x := range args {
		switch x {
		case "--autostart-on":
			if e := app.setAutostart(true); e != nil {
				fmt.Fprintln(os.Stderr, e)
				os.Exit(1)
			}
			fmt.Println("CampusBoop startup enabled.")
			return
		case "--autostart-off":
			if e := app.setAutostart(false); e != nil {
				fmt.Fprintln(os.Stderr, e)
				os.Exit(1)
			}
			fmt.Println("CampusBoop startup disabled.")
			return
		}
	}
	if background && app.cfg.StartupReminderEnabled {
		app.rt.StartupReminderAt = time.Now().Add(time.Duration(app.cfg.StartupDelayMinutes) * time.Minute)
		app.rt.StartupReminderShown = false
	} else {
		app.rt.StartupReminderShown = true
	}
	lock, e := acquireLock(filepath.Join(app.dataDir, "instance.lock"))
	if e != nil {
		if !background && openExisting(app.dataDir) {
			return
		}
		return
	}
	defer lock.Close()
	mux := http.NewServeMux()
	mux.HandleFunc("/api/state", app.handleAPI)
	mux.HandleFunc("/api/action", app.handleAPI)
	assets, _ := fs.Sub(content, "assets")
	mux.Handle("/assets/", http.StripPrefix("/assets/", http.FileServer(http.FS(assets))))
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		b, e := content.ReadFile("ui.html")
		if e != nil {
			http.Error(w, "UI missing", 500)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Cache-Control", "no-store")
		_, _ = w.Write(b)
	})
	ln, e := net.Listen("tcp", "127.0.0.1:0")
	if e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
	app.listener = ln
	_, port, _ := net.SplitHostPort(ln.Addr().String())
	_ = os.WriteFile(app.portPath, []byte(port), 0600)
	defer os.Remove(app.portPath)
	app.server = &http.Server{Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	go app.reminderLoop()
	go func() { _ = app.server.Serve(ln) }()
	if !background || !app.cfg.BackgroundEnabled {
		_ = openBrowser(app.uiURL(""))
	}
	<-app.done
}
