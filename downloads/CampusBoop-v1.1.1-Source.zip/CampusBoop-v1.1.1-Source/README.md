# CampusBoop v1.1.1 source package

CampusBoop is an independent student-made project and is not an official HvA or UvA application.

Folders:
- `Windows/` — Windows CampusBoop files/source used for the v1.1.1 Windows package.
- `Linux/` — Go source and local web UI used to build Linux x64 and ARM64.
- `Website/` — one-page public website and quick installer scripts.

Public site: https://campusboop.creatorpromote.com/
