Option Explicit
Dim shell, files, folder, scriptPath, powershellPath
Set shell = CreateObject("WScript.Shell")
Set files = CreateObject("Scripting.FileSystemObject")
folder = files.GetParentFolderName(WScript.ScriptFullName)
scriptPath = files.BuildPath(folder, "CampusBoop.exe")
shell.Run """" & scriptPath & """", 0, False
