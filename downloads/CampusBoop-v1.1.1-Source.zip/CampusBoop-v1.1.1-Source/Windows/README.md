# CampusBoop v1.1.1 - Windows x64

CampusBoop is an independent student-made helper for HvA/UvA students. It is not an official HvA or UvA application.

## Start
1. Extract the ZIP completely.
2. Open `CampusBoop\CampusBoop.exe`.
3. Complete the first-run setup.
4. CampusBoop stores your settings only for your Windows user under `%LOCALAPPDATA%\SchoolCheckInHelper`.

The first run of an unsigned downloaded Windows app can trigger a Windows SmartScreen/unknown-publisher warning. CampusBoop does not disable Windows security.

## What first-run setup configures
- HvA or UvA trusted sign-in host
- background/start-with-Windows behavior
- startup and VS Code check-in reminders
- checkout reminders
- optional trusted HvA/UvA login autofill (ID + password can be entered during first setup)

Personal login autofill is optional and can be configured during first setup or later in Settings → Personal login. Saved credentials are protected locally with Windows DPAPI and are only used on the trusted HvA/UvA ADFS sign-in path.

## Student tools
Default Print, Top up and Library links are selected for HvA/UvA and can be renamed or replaced in Settings.
