using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

internal sealed class SchoolLogin : Form
{
    private readonly WebView2 browser = new WebView2();
    private readonly TextBox address = new TextBox();
    private readonly Label status = new Label();
    private readonly Timer timer = new Timer();
    private readonly string initialUrl;
    private readonly string dataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SchoolCheckInHelper");
    private bool submitted, busy;
    private readonly JavaScriptSerializer json = new JavaScriptSerializer();

    [STAThread]
    private static void Main(string[] args)
    {
        Application.EnableVisualStyles();
        Uri uri;
        if (args.Length != 2 || args[0] != "--url" || !Uri.TryCreate(args[1], UriKind.Absolute, out uri) || uri.Scheme != "https") return;
        Application.Run(new SchoolLogin(uri.AbsoluteUri));
    }

    private SchoolLogin(string url)
    {
        initialUrl = url;
        Text = "CampusBoop - trusted school browser";
        Size = new Size(1100, 800); StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 10);
        string icon = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"assets\creatorpromote.ico");
        if (File.Exists(icon)) Icon = new Icon(icon);
        var header = new Panel { Dock = DockStyle.Top, Height = 88, BackColor = Color.FromArgb(244, 243, 250) };
        address.ReadOnly = true; address.Dock = DockStyle.Top; address.Height = 28;
        status.Dock = DockStyle.Fill; status.Padding = new Padding(12);
        status.Text = "Loading. CampusBoop only automates known school-choice pages and the selected HvA/UvA ADFS login. MFA stays manual.";
        header.Controls.Add(status); header.Controls.Add(address);
        browser.Dock = DockStyle.Fill; Controls.Add(browser); Controls.Add(header);
        timer.Interval = 800;
        timer.Tick += async delegate { await TryAutomation(); };
        Shown += async delegate { await Initialize(); };
        FormClosed += delegate { timer.Stop(); timer.Dispose(); browser.Dispose(); };
    }

    private async Task Initialize()
    {
        try
        {
            var environment = await CoreWebView2Environment.CreateAsync(null, Path.Combine(dataDir, "BrowserProfile"));
            await browser.EnsureCoreWebView2Async(environment);
            browser.CoreWebView2.Settings.IsPasswordAutosaveEnabled = false;
            browser.CoreWebView2.Settings.IsGeneralAutofillEnabled = false;
            browser.CoreWebView2.NavigationStarting += delegate(object sender, CoreWebView2NavigationStartingEventArgs e)
            {
                Uri target;
                if (!Uri.TryCreate(e.Uri, UriKind.Absolute, out target) || target.Scheme != "https")
                {
                    e.Cancel = true;
                    status.Text = "Only HTTPS navigation is allowed.";
                }
            };
            browser.CoreWebView2.SourceChanged += delegate { address.Text = browser.CoreWebView2.Source; };
            browser.CoreWebView2.NewWindowRequested += delegate(object sender, CoreWebView2NewWindowRequestedEventArgs e)
            {
                e.Handled = true;
                Uri target;
                if (Uri.TryCreate(e.Uri, UriKind.Absolute, out target) && target.Scheme == "https")
                    Process.Start(new ProcessStartInfo(target.AbsoluteUri) { UseShellExecute = true });
            };
            browser.CoreWebView2.Navigate(initialUrl);
            timer.Start();
        }
        catch
        {
            status.Text = "The trusted browser could not start. Use your normal browser, or install Microsoft Edge WebView2 Runtime.";
            var normal = new Button { Text = "Open in normal browser", Dock = DockStyle.Bottom, Height = 40 };
            normal.Click += delegate { Process.Start(new ProcessStartInfo(initialUrl) { UseShellExecute = true }); };
            Controls.Add(normal); normal.BringToFront();
        }
    }

    private Dictionary<string, object> ReadSettings()
    {
        string settingsPath = Path.Combine(dataDir, "settings.json");
        if (!File.Exists(settingsPath)) return null;
        try { return json.Deserialize<Dictionary<string, object>>(File.ReadAllText(settingsPath)); }
        catch { return null; }
    }

    private static string SchoolFromSettings(Dictionary<string, object> settings)
    {
        object value;
        if (settings != null && settings.TryGetValue("schoolProvider", out value))
        {
            string s = Convert.ToString(value).ToLowerInvariant();
            if (s == "uva") return "uva";
            if (s == "hva") return "hva";
        }
        if (settings != null && settings.TryGetValue("loginProvider", out value) && Convert.ToString(value).Equals("login.uva.nl", StringComparison.OrdinalIgnoreCase)) return "uva";
        return "hva";
    }

    internal static bool IsTrusted(Uri uri, string provider)
    {
        return (provider == "login.hva.nl" || provider == "login.uva.nl") && uri.Scheme == "https" && uri.Port == 443 &&
            uri.Host.Equals(provider, StringComparison.OrdinalIgnoreCase) && uri.AbsolutePath.StartsWith("/adfs/ls/", StringComparison.OrdinalIgnoreCase);
    }

    internal static string AutofillScript(string provider, string idValue, string passwordValue)
    {
        var serializer = new JavaScriptSerializer();
        return "(() => { if(location.protocol!=='https:' || location.hostname!==" + serializer.Serialize(provider) +
            " || (location.port && location.port!=='443') || !location.pathname.toLowerCase().startsWith('/adfs/ls/')) return 'wrong-site';" +
            "const id=document.getElementById('userNameInput'),pw=document.getElementById('passwordInput'),submit=document.getElementById('submitButton');" +
            "if(!id||!pw||!submit||pw.type!=='password'||!id.getClientRects().length||!pw.getClientRects().length) return 'not-ready';" +
            "const error=document.getElementById('errorText'); if(error && error.textContent.trim()) return 'error';" +
            "id.value=" + serializer.Serialize(idValue) + "; pw.value=" + serializer.Serialize(passwordValue) + ";" +
            "for(const field of [id,pw]){field.dispatchEvent(new Event('input',{bubbles:true}));field.dispatchEvent(new Event('change',{bubbles:true}));}" +
            "submit.click();return 'submitted';})()";
    }

    private static bool ExactHost(Uri uri, string host)
    {
        return uri.Scheme == "https" && (uri.IsDefaultPort || uri.Port == 443) && uri.Host.Equals(host, StringComparison.OrdinalIgnoreCase);
    }

    private async Task<string> TryTrustedChoice(Uri current, string school)
    {
        string script = null;
        string expectedPrintHost = school == "uva" ? "uva.mycampusprint.nl" : "hva.mycampusprint.nl";

        if (ExactHost(current, expectedPrintHost) && current.AbsolutePath.StartsWith("/Login", StringComparison.OrdinalIgnoreCase))
        {
            script = @"(() => {
                if (window.__campusBoopChoiceDone) return 'already';
                const visible=e=>!!(e && e.getClientRects && e.getClientRects().length);
                const txt=e=>((e.innerText||e.textContent||e.value||e.getAttribute('aria-label')||'')+'').trim().toLowerCase();
                const items=[...document.querySelectorAll('button,a,input[type=submit],input[type=button],label')].filter(visible);
                const student=items.find(e=>{const t=txt(e);return !t.includes('guest') && (t.includes('student')||t.includes('student id')||t.includes('studenten'));});
                if(!student) return 'not-ready'; window.__campusBoopChoiceDone=true; student.click(); return 'student-login';
            })()";
        }
        else if (ExactHost(current, "uva-hva.mynetpay.nl") && current.AbsolutePath.StartsWith("/Auth", StringComparison.OrdinalIgnoreCase))
        {
            string target = school == "uva" ? "uva" : "hva";
            string longName = school == "uva" ? "universiteit van amsterdam" : "hogeschool van amsterdam";
            string altName = school == "uva" ? "university of amsterdam" : "amsterdam university of applied sciences";
            script = "(() => {" +
                "if(window.__campusBoopChoiceDone)return 'already';" +
                "const visible=e=>!!(e&&e.getClientRects&&e.getClientRects().length);" +
                "const txt=e=>((e.innerText||e.textContent||e.value||e.getAttribute('aria-label')||'')+'').trim().toLowerCase();" +
                "const items=[...document.querySelectorAll('button,a,input[type=submit],input[type=button],label')].filter(visible);" +
                "const target=" + json.Serialize(target) + ", longName=" + json.Serialize(longName) + ", altName=" + json.Serialize(altName) + ";" +
                "const choice=items.find(e=>{const t=txt(e);return t===target||t.includes(longName)||t.includes(altName)||t.startsWith(target+' ')||t.endsWith(' '+target);});" +
                "if(!choice)return 'not-ready';window.__campusBoopChoiceDone=true;choice.click();return 'school-choice';})()";
        }
        else if ((school == "hva" && ExactHost(current, "lib.hva.nl")) || (school == "uva" && ExactHost(current, "lib.uva.nl")))
        {
            string schoolToken = school == "uva" ? "uva" : "hva";
            script = "(() => {" +
                "if(window.__campusBoopChoiceDone)return 'already';" +
                "const visible=e=>!!(e&&e.getClientRects&&e.getClientRects().length);" +
                "const txt=e=>((e.innerText||e.textContent||e.value||e.getAttribute('aria-label')||'')+'').trim().toLowerCase();" +
                "const items=[...document.querySelectorAll('button,a,input[type=submit],input[type=button],label')].filter(visible);" +
                "const school=" + json.Serialize(schoolToken) + ";" +
                "let choice=items.find(e=>{const t=txt(e);return t.includes('student')&&(t.includes(school)||t.includes('university')||t.includes('hogeschool'));});" +
                "if(!choice)choice=items.find(e=>{const t=txt(e);return t==='login'||t==='log in'||t==='sign in'||t==='inloggen'||t==='aanmelden';});" +
                "if(!choice)return 'not-ready';window.__campusBoopChoiceDone=true;choice.click();return 'library-choice';})()";
        }

        if (script == null) return null;
        try
        {
            string result = await browser.CoreWebView2.ExecuteScriptAsync(script);
            if (result == "\"student-login\"") return "Choosing the student login for " + (school == "uva" ? "UvA" : "HvA") + ".";
            if (result == "\"school-choice\"") return "Choosing " + (school == "uva" ? "UvA" : "HvA") + " on the trusted top-up page.";
            if (result == "\"library-choice\"") return "Continuing through the trusted library login.";
        }
        catch { }
        return null;
    }

    private async Task TryAutomation()
    {
        if (busy || browser.CoreWebView2 == null) return;
        busy = true;
        try
        {
            var settings = ReadSettings();
            if (settings == null) return;
            string school = SchoolFromSettings(settings);
            Uri current;
            if (!Uri.TryCreate(browser.CoreWebView2.Source, UriKind.Absolute, out current) || current.Scheme != "https") return;

            string choiceStatus = await TryTrustedChoice(current, school);
            if (!string.IsNullOrEmpty(choiceStatus))
            {
                status.Text = choiceStatus + " CampusBoop will only continue automatically on known trusted school pages.";
                return;
            }

            if (submitted) return;
            object enabled, providerValue;
            if (!settings.TryGetValue("autoLoginEnabled", out enabled) || !Convert.ToBoolean(enabled))
            {
                status.Text = "Trusted helper active. Saved credential autofill is off, so sign in manually when the school login appears.";
                return;
            }
            if (!settings.TryGetValue("loginProvider", out providerValue)) return;
            string provider = Convert.ToString(providerValue);
            if (!IsTrusted(current, provider)) return;

            string loginPath = Path.Combine(dataDir, "login.bin");
            if (!File.Exists(loginPath)) { status.Text = "No saved login. Sign in manually."; return; }
            byte[] clear = ProtectedData.Unprotect(File.ReadAllBytes(loginPath), null, DataProtectionScope.CurrentUser);
            Dictionary<string, string> credentials;
            try { credentials = json.Deserialize<Dictionary<string, string>>(Encoding.UTF8.GetString(clear)); }
            finally { Array.Clear(clear, 0, clear.Length); }
            if (credentials == null || !credentials.ContainsKey("id") || !credentials.ContainsKey("password") || string.IsNullOrEmpty(credentials["id"]) || string.IsNullOrEmpty(credentials["password"])) return;

            string script = AutofillScript(provider, credentials["id"], credentials["password"]);
            credentials.Clear();
            string result = await browser.CoreWebView2.ExecuteScriptAsync(script);
            script = null;
            if (result == "\"submitted\"")
            {
                submitted = true;
                status.Text = "Login submitted once on the trusted " + provider + " page. Complete phone verification if requested.";
            }
            else if (result == "\"error\"")
            {
                submitted = true;
                status.Text = "School reported a login error. Automatic retries stopped; check your details manually.";
            }
        }
        catch
        {
            submitted = true;
            status.Text = "Automatic login could not run. Continue manually or update CampusBoop Settings.";
        }
        finally { busy = false; }
    }
}
