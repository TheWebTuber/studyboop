@echo off
cd /d "%~dp0"
start "CampusBoop" "%~dp0CampusBoop.exe"
