param([switch]$Background)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Web.Extensions
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class SchoolWindow {
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
}
'@
[System.Windows.Forms.Application]::EnableVisualStyles()

# Once CampusBoop has been allowed to run, quietly remove Internet-zone markers
# from its own extracted files. This prevents repeated Windows attachment warnings
# for helper binaries/scripts. It does not bypass SmartScreen before the first run.
try {
    Get-ChildItem -LiteralPath $PSScriptRoot -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
} catch { }

$mutex = New-Object System.Threading.Mutex($false, 'Local\CampusBoop')
if (-not $mutex.WaitOne(0)) {
    if (-not $Background) {
        $openDir = Join-Path $env:LOCALAPPDATA 'SchoolCheckInHelper'
        [IO.Directory]::CreateDirectory($openDir) | Out-Null
        [IO.File]::WriteAllText((Join-Path $openDir 'open-request'), 'open')
    }
    $mutex.Dispose(); exit
}

$script:dataDir = Join-Path $env:LOCALAPPDATA 'SchoolCheckInHelper'
[IO.Directory]::CreateDirectory($script:dataDir) | Out-Null
$script:configPath = Join-Path $script:dataDir 'settings.json'
$script:statePath = Join-Path $script:dataDir 'state.json'
. (Join-Path $PSScriptRoot 'Preferences.ps1')

$script:config = [pscustomobject]@{
    loginUrl = 'https://dlo.mijnhva.nl/d2l/home'
    checkinUrl = 'https://dlo.mijnhva.nl/d2l/le/lessons/762152/topics/2936746'
    option1Name = 'Check-in 1'; option1Url = ''
    option2Name = 'Check-in 2'; option2Url = ''
    tool1Name = 'Print'; tool1Url = 'https://hva.mycampusprint.nl/Login/Login'
    tool2Name = 'Top up'; tool2Url = 'https://uva-hva.mynetpay.nl/Auth/Login'
    tool3Name = 'Library'; tool3Url = 'https://lib.hva.nl'
    cooldownMinutes = 60
    reminderMinutes = 45; backgroundEnabled = $true; onboardingComplete = $false
    smartReminderEnabled = $true; startupReminderEnabled = $true; startupDelayMinutes = 2
    checkoutReminderEnabled = $true; checkoutLeadMinutes = 15; dayResetHour = 4
    autoLoginEnabled = $false; schoolProvider = 'hva'; loginProvider = 'login.hva.nl'
    scheduleEnabled = $false; weeklySchedule = @(New-WeekSchedule)
}

function Save-Config { $script:config | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $script:configPath -Encoding UTF8 }
if (Test-Path -LiteralPath $script:configPath) {
    try {
        $saved = Get-Content -LiteralPath $script:configPath -Raw | ConvertFrom-Json
        foreach ($p in $script:config.PSObject.Properties) {
            if ($saved.PSObject.Properties.Name -contains $p.Name) { $p.Value = $saved.($p.Name) }
        }
    } catch { }
}
if ([string]$script:config.schoolProvider -notin @('hva','uva')) {
    $script:config.schoolProvider = if ([string]$script:config.loginProvider -eq 'login.uva.nl') { 'uva' } else { 'hva' }
}
$script:config.loginProvider = if ($script:config.schoolProvider -eq 'uva') { 'login.uva.nl' } else { 'login.hva.nl' }
if ([int]$script:config.startupDelayMinutes -lt 1 -or [int]$script:config.startupDelayMinutes -gt 60) { $script:config.startupDelayMinutes = 2 }
if ([int]$script:config.checkoutLeadMinutes -lt 0 -or [int]$script:config.checkoutLeadMinutes -gt 180) { $script:config.checkoutLeadMinutes = 15 }
if ([int]$script:config.dayResetHour -lt 0 -or [int]$script:config.dayResetHour -gt 12) { $script:config.dayResetHour = 4 }

function Ensure-SchoolLoginHelper {
    $source = Join-Path $PSScriptRoot 'SchoolLogin.cs'
    $target = Join-Path $PSScriptRoot 'SchoolLogin.exe'
    if (-not (Test-Path -LiteralPath $source)) { return }
    $needsBuild = -not (Test-Path -LiteralPath $target)
    if (-not $needsBuild) {
        try { $needsBuild = (Get-Item -LiteralPath $source).LastWriteTimeUtc -gt (Get-Item -LiteralPath $target).LastWriteTimeUtc } catch { $needsBuild = $true }
    }
    if (-not $needsBuild) { return }
    $temp = Join-Path $PSScriptRoot 'SchoolLogin.new.exe'
    try {
        Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
        $refs = @(
            [System.Windows.Forms.Form].Assembly.Location,
            [System.Drawing.Image].Assembly.Location,
            [System.Web.Script.Serialization.JavaScriptSerializer].Assembly.Location,
            [System.Security.Cryptography.ProtectedData].Assembly.Location,
            (Join-Path $PSScriptRoot 'Microsoft.Web.WebView2.Core.dll'),
            (Join-Path $PSScriptRoot 'Microsoft.Web.WebView2.WinForms.dll')
        )
        Add-Type -Path $source -ReferencedAssemblies $refs -OutputAssembly $temp -OutputType WindowsApplication -ErrorAction Stop | Out-Null
        Move-Item -LiteralPath $temp -Destination $target -Force
    } catch {
        Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
    }
}

function Ensure-Launcher {
    $source = Join-Path $PSScriptRoot 'Launcher.cs'
    $target = Join-Path $PSScriptRoot 'CampusBoop.exe'
    if (-not (Test-Path -LiteralPath $source) -or -not (Test-Path -LiteralPath $target)) { return }
    try {
        if ((Get-Item -LiteralPath $source).LastWriteTimeUtc -le (Get-Item -LiteralPath $target).LastWriteTimeUtc) { return }
        $temp = Join-Path $PSScriptRoot 'CampusBoop.new.exe'
        Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
        Add-Type -Path $source -ReferencedAssemblies @([System.Windows.Forms.Form].Assembly.Location) -OutputAssembly $temp -OutputType WindowsApplication -ErrorAction Stop | Out-Null
        Move-Item -LiteralPath $temp -Destination $target -Force
    } catch { Remove-Item -LiteralPath (Join-Path $PSScriptRoot 'CampusBoop.new.exe') -Force -ErrorAction SilentlyContinue }
}
Ensure-Launcher

$script:doneDate = ''
$script:checkoutDate = ''
if (Test-Path -LiteralPath $script:statePath) {
    try {
        $state = Get-Content -LiteralPath $script:statePath -Raw | ConvertFrom-Json
        $script:doneDate = $state.doneDate
        if ($state.PSObject.Properties.Name -contains 'checkoutDate') { $script:checkoutDate = $state.checkoutDate }
    } catch { }
}
$script:nextReminder = [datetime]::MinValue
$script:nextCommitReminder = (Get-Date).AddMinutes([int]$script:config.reminderMinutes)
$script:lastNotification = 'checkin'
$script:commitDialog = $null
$script:breakUntil = [datetime]::MinValue
$script:paused = $false
$script:dialog = $null
$script:checkoutDialog = $null
$script:checkoutReminderDay = ''
$script:hadCodeWindow = $false
$script:startupReminderShown = -not $Background
$script:startupReminderAt = [datetime]::MaxValue
if ($Background -and [bool]$script:config.startupReminderEnabled) {
    $script:startupReminderAt = (Get-Date).AddMinutes([int]$script:config.startupDelayMinutes)
}

function Save-State {
    @{ doneDate = $script:doneDate; checkoutDate = $script:checkoutDate } | ConvertTo-Json | Set-Content -LiteralPath $script:statePath -Encoding UTF8
}

function Get-CampusDay([datetime]$when = (Get-Date)) {
    $adjusted = $when
    if ($when.Hour -lt [int]$script:config.dayResetHour) { $adjusted = $when.AddDays(-1) }
    return $adjusted.ToString('yyyy-MM-dd')
}

function Get-TodayState {
    $day = Get-CampusDay
    if ($script:checkoutDate -eq $day) { return 'checkedout' }
    if ($script:doneDate -eq $day) { return 'checkedin' }
    return 'notcheckedin'
}

function Get-TodayStatusText {
    switch (Get-TodayState) {
        'checkedin'  { return 'Today: checked in - check-in reminders are quiet; work and checkout reminders stay active.' }
        'checkedout' { return 'Today: checked out - CampusBoop is quiet until the next school day.' }
        default      { return 'Today: not checked in yet - startup and smart check-in reminders can still appear.' }
    }
}

function Show-Centered($form) {
    Set-BrandTheme $form
    $form.TopMost = $true
    $form.Show(); $form.Activate(); $form.BringToFront(); $form.TopMost = $false
}

function Set-BrandTheme($form) {
    if ($form.Tag -eq 'branded') { return }
    $form.Tag = 'branded'
    # Resizable Windows UI with a compact, centered CampusBoop + HvA/UvA header.
    $form.FormBorderStyle = 'Sizable'; $form.MaximizeBox = $true; $form.MinimizeBox = $true
    $form.AutoScroll = $true
    $form.AutoScaleMode = [Windows.Forms.AutoScaleMode]::Dpi
    $iconPath = Join-Path $PSScriptRoot 'assets\creatorpromote.ico'
    if (Test-Path -LiteralPath $iconPath) { $form.Icon = New-Object Drawing.Icon($iconPath) }
    $form.Font = New-Object Drawing.Font('Segoe UI',8.5)
    $form.BackColor = [Drawing.ColorTranslator]::FromHtml('#F4F3FA')
    $form.ForeColor = [Drawing.ColorTranslator]::FromHtml('#241D3A')

    # CampusBoop sits above both school logos. No version/test text is shown in the app UI.
    $headerHeight = 70
    $shift = 76
    $form.ClientSize = New-Object Drawing.Size($form.ClientSize.Width,($form.ClientSize.Height + $shift))
    $minW = [Math]::Max(480,[Math]::Min(620,($form.ClientSize.Width - 40)))
    $minH = [Math]::Max(300,[Math]::Min(540,($form.ClientSize.Height - 55)))
    $form.MinimumSize = New-Object Drawing.Size(($minW + 16),($minH + 39))

    foreach ($control in @($form.Controls)) {
        $hasBottom = (($control.Anchor -band [Windows.Forms.AnchorStyles]::Bottom) -ne 0)
        $hasTop = (($control.Anchor -band [Windows.Forms.AnchorStyles]::Top) -ne 0)
        if ($hasBottom -and -not $hasTop) {
            # Bottom-anchored controls move automatically when ClientSize grows.
        } elseif ($hasBottom -and $hasTop) {
            $control.Height = [Math]::Max(24,($control.Height - $shift)); $control.Top += $shift
        } else { $control.Top += $shift }

        if ($control -is [Windows.Forms.Button]) {
            $control.FlatStyle = 'Flat'
            $control.FlatAppearance.BorderColor = [Drawing.ColorTranslator]::FromHtml('#CEC9E2')
            if ($control.Width -le 28 -and $control.Text -eq [string][char]0x24D8) {
                $control.BackColor = [Drawing.Color]::Transparent
                $control.FlatAppearance.BorderSize = 0
            } else { $control.BackColor = [Drawing.Color]::White }
            $control.Cursor = [Windows.Forms.Cursors]::Hand
            $control.AutoEllipsis = $true
            if ($control.Text -match 'checked in|checked out|Save choices') {
                $control.BackColor = [Drawing.ColorTranslator]::FromHtml('#25167A')
                $control.ForeColor = [Drawing.Color]::White
            }
        }
    }

    $header = New-Object Windows.Forms.Panel
    $header.Anchor = 'Top,Left,Right'
    $header.Location = New-Object Drawing.Point(0,0)
    $header.Size = New-Object Drawing.Size($form.ClientSize.Width,$headerHeight)
    $header.BackColor = [Drawing.Color]::White
    $form.Controls.Add($header)

    $title = New-Object Windows.Forms.Label
    $title.Text = 'CampusBoop'
    $title.TextAlign = [Drawing.ContentAlignment]::MiddleCenter
    $title.Font = New-Object Drawing.Font('Segoe UI',10,[Drawing.FontStyle]::Bold)
    $title.ForeColor = [Drawing.ColorTranslator]::FromHtml('#25167A')
    $title.Location = New-Object Drawing.Point(0,4)
    $title.Size = New-Object Drawing.Size($header.ClientSize.Width,22)
    $title.Anchor = 'Top,Left,Right'
    $header.Controls.Add($title)

    $logoBoxes = @()
    foreach ($name in @('hva','uva')) {
        $path = Join-Path $PSScriptRoot ('assets\' + $name + '.png')
        if (Test-Path -LiteralPath $path) {
            $picture = New-Object Windows.Forms.PictureBox
            $picture.SizeMode = 'Zoom'
            $picture.Image = [Drawing.Image]::FromFile($path)
            $header.Controls.Add($picture)
            $logoBoxes += $picture
        }
    }

    $layoutBrand = {
        $title.Width = $header.ClientSize.Width
        if ($logoBoxes.Count -eq 0) { return }
        $gap = 12
        $logoW = [Math]::Min(138,[Math]::Max(105,[int](($header.ClientSize.Width - 48 - $gap) / 2)))
        $logoH = 29
        $total = ($logoW * $logoBoxes.Count) + ($gap * [Math]::Max(0,$logoBoxes.Count - 1))
        $x = [Math]::Max(8,[int](($header.ClientSize.Width - $total) / 2))
        foreach ($picture in $logoBoxes) {
            $picture.Location = New-Object Drawing.Point($x,32)
            $picture.Size = New-Object Drawing.Size($logoW,$logoH)
            $x += $logoW + $gap
        }
    }.GetNewClosure()
    $header.Add_SizeChanged($layoutBrand)
    & $layoutBrand

    $form.Add_FormClosed({
        param($sender,$eventArgs)
        foreach ($panel in $sender.Controls) {
            foreach ($child in $panel.Controls) {
                if ($child -is [Windows.Forms.PictureBox] -and $child.Image) { $child.Image.Dispose() }
            }
        }
    })
}
if ($null -eq $script:tooltipRefs) { $script:tooltipRefs = @() }

function New-InfoIcon($form, [string]$description, [int]$left, [int]$top) {
    $info = New-Object Windows.Forms.Button
    $info.Text = [char]0x24D8
    $info.Location = New-Object Drawing.Point($left,$top)
    $info.Size = New-Object Drawing.Size(26,32)
    $info.FlatStyle = 'Flat'
    $info.FlatAppearance.BorderSize = 0
    $info.BackColor = [Drawing.Color]::Transparent
    $info.ForeColor = [Drawing.ColorTranslator]::FromHtml('#5F5874')
    $info.Cursor = [Windows.Forms.Cursors]::Hand
    $tip = New-Object Windows.Forms.ToolTip
    $tip.AutoPopDelay = 9000; $tip.InitialDelay = 250; $tip.ReshowDelay = 100
    $tip.SetToolTip($info,$description)
    $script:tooltipRefs += $tip
    $handler = {
        [Windows.Forms.MessageBox]::Show($form,$description,'CampusBoop info',[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Information) | Out-Null
    }.GetNewClosure()
    $info.Add_Click($handler)
    $form.Controls.Add($info)
    return $info
}

function New-CompactAction($form, [string]$text, [string]$description, [int]$left, [int]$top, [int]$width, $action) {
    $button = New-Object Windows.Forms.Button
    $button.Text = $text
    $button.Location = New-Object Drawing.Point($left,$top)
    $button.Size = New-Object Drawing.Size(($width - 30),32)
    $button.AutoEllipsis = $true
    $button.Add_Click($action)
    $form.Controls.Add($button)
    $tip = New-Object Windows.Forms.ToolTip
    $tip.AutoPopDelay = 9000; $tip.InitialDelay = 250; $tip.ReshowDelay = 100
    $tip.SetToolTip($button,$description)
    $script:tooltipRefs += $tip
    $info = New-InfoIcon $form $description ($left + $width - 28) $top
    $button.Tag = $info
    return $button
}

function Open-Link([string]$url, [bool]$preferHelper = $false) {
    $uri = $null
    if (-not [Uri]::TryCreate($url, [UriKind]::Absolute, [ref]$uri) -or $uri.Scheme -ne 'https') {
        try { Show-Settings } catch { }
        return
    }
    $helper = Join-Path $PSScriptRoot 'SchoolLogin.exe'
    if ($preferHelper -or ($script:config.autoLoginEnabled -and (Test-Path -LiteralPath (Join-Path $script:dataDir 'login.bin')))) {
        Ensure-SchoolLoginHelper
        if (Test-Path -LiteralPath $helper) {
            Start-Process -FilePath $helper -ArgumentList @('--url', ('"' + $uri.AbsoluteUri + '"'))
            return
        }
    }
    Start-Process -FilePath $uri.AbsoluteUri
}

function New-Button($form, [string]$text, [int]$top, $action) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $text; $b.Location = New-Object Drawing.Point(20,$top)
    $b.Size = New-Object Drawing.Size(420,34)
    $b.Anchor = 'Top,Left,Right'
    $b.Add_Click($action); $form.Controls.Add($b)
}

function New-DescribedButton($form, [string]$text, [string]$description, [int]$top, $action) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $text; $b.Location = New-Object Drawing.Point(20,$top)
    $b.Size = New-Object Drawing.Size(($form.ClientSize.Width - 40),34)
    $b.Anchor = 'Top,Left,Right'; $b.Add_Click($action); $form.Controls.Add($b)
    $d = New-Object System.Windows.Forms.Label
    $d.Text = $description; $d.Location = New-Object Drawing.Point(24,($top + 39))
    $d.Size = New-Object Drawing.Size(($form.ClientSize.Width - 48),32)
    $d.ForeColor = [Drawing.ColorTranslator]::FromHtml('#5F5874')
    $d.Anchor = 'Top,Left,Right'; $form.Controls.Add($d)
}

function New-ToolButton($form, [string]$text, [int]$left, $action) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $text; $b.Location = New-Object Drawing.Point($left,535)
    $b.Size = New-Object Drawing.Size(130,36)
    $b.Add_Click($action); $form.Controls.Add($b)
}

function Set-CheckedIn {
    $script:doneDate = Get-CampusDay
    $script:checkoutDate = ''
    $script:nextCommitReminder = (Get-Date).AddMinutes([int]$script:config.reminderMinutes)
    $script:checkoutReminderDay = ''
    Save-State
    if ($script:dialog -and -not $script:dialog.IsDisposed) { $script:dialog.Close() }
}

function Set-CheckedOut {
    $script:checkoutDate = Get-CampusDay
    Save-State
    foreach ($form in @($script:dialog,$script:commitDialog,$script:checkoutDialog)) {
        if ($form -and -not $form.IsDisposed) { $form.Close() }
    }
}

function Show-Checkout {
    if ((Get-TodayState) -ne 'checkedin') { return }
    if ($script:checkoutDialog -and -not $script:checkoutDialog.IsDisposed) { $script:checkoutDialog.Activate(); return }
    $f = New-Object System.Windows.Forms.Form
    $script:checkoutDialog = $f
    $f.Text = 'Boop - ready to check out?'; $f.ClientSize = New-Object Drawing.Size(500,155)
    $f.StartPosition = 'CenterScreen'

    $label = New-Object System.Windows.Forms.Label
    $label.Text = 'You are checked in. Before leaving, make sure the school checkout is actually submitted.'
    $label.Location = New-Object Drawing.Point(14,10); $label.Size = New-Object Drawing.Size(472,36)
    $f.Controls.Add($label)

    New-CompactAction $f 'Open school page' 'Opens your configured school check-in / checkout page. CampusBoop does not assume the checkout succeeded.' 14 52 230 { Open-Link $script:config.checkinUrl } | Out-Null
    New-CompactAction $f "I've checked out" 'Marks today complete in CampusBoop. Check-in, work and checkout reminders stop until the next school day.' 256 52 230 { Set-CheckedOut } | Out-Null
    New-CompactAction $f 'Still working - remind me later' 'Closes this popup without changing your checked-in state. Your work reminders continue.' 14 94 472 { $script:checkoutDialog.Close() } | Out-Null

    $f.Add_FormClosed({ $script:checkoutDialog = $null })
    Show-Centered $f
}

function Start-Break {
    $script:breakUntil = (Get-Date).AddMinutes(10)
    $script:nextCommitReminder = $script:breakUntil.AddMinutes([int]$script:config.reminderMinutes)
    foreach ($form in @($script:commitDialog,$script:checkoutDialog)) {
        if ($form -and -not $form.IsDisposed) { $form.Close() }
    }
}
function Resume-Work {
    $script:breakUntil = [datetime]::MinValue
    $script:nextCommitReminder = (Get-Date).AddMinutes([int]$script:config.reminderMinutes)
}

function Show-CommitReminder {
    if ((Get-TodayState) -ne 'checkedin') { return }
    if ($script:commitDialog -and -not $script:commitDialog.IsDisposed) { $script:commitDialog.Activate(); return }
    $f = New-Object System.Windows.Forms.Form
    $script:commitDialog = $f
    $f.Text = 'Boop - save your work'; $f.ClientSize = New-Object Drawing.Size(500,155)
    $f.StartPosition = 'CenterScreen'
    $label = New-Object System.Windows.Forms.Label
    $label.Text = 'Checked in and coding. Save/commit your work and remember to take a breather.'
    $label.Location = New-Object Drawing.Point(14,10); $label.Size = New-Object Drawing.Size(472,36)
    $f.Controls.Add($label)
    New-CompactAction $f 'Got it' 'Close this reminder. The next commit/break reminder uses your normal reminder interval.' 14 52 230 { $script:commitDialog.Close() } | Out-Null
    New-CompactAction $f 'Keep working' 'Close this popup and continue working. Your checked-in state stays active.' 256 52 230 { $script:commitDialog.Close() } | Out-Null
    New-CompactAction $f 'Take a 10-minute break' 'Pauses work reminders for 10 minutes, then CampusBoop resumes them automatically.' 14 94 472 { Start-Break } | Out-Null
    $f.Add_FormClosed({
        $script:commitDialog = $null
        $script:nextCommitReminder = (Get-Date).AddMinutes([int]$script:config.reminderMinutes)
        if ($script:breakUntil -gt (Get-Date)) { $script:nextCommitReminder = $script:breakUntil.AddMinutes([int]$script:config.reminderMinutes) }
    })
    Show-Centered $f
}

function Show-Checkin {
    if ($script:dialog -and -not $script:dialog.IsDisposed) { $script:dialog.Activate(); return }
    $f = New-Object System.Windows.Forms.Form
    $script:dialog = $f
    $f.Text = 'CampusBoop'; $f.ClientSize = New-Object Drawing.Size(590,338)
    $f.StartPosition = 'CenterScreen'

    $status = New-Object System.Windows.Forms.Label
    $status.Text = Get-TodayStatusText
    $status.Font = New-Object Drawing.Font('Segoe UI',8.5,[Drawing.FontStyle]::Bold)
    $status.ForeColor = [Drawing.ColorTranslator]::FromHtml('#25167A')
    $status.Location = New-Object Drawing.Point(14,10); $status.Size = New-Object Drawing.Size(562,34)
    $status.Anchor = 'Top,Left,Right'; $f.Controls.Add($status)

    $checkedInButton = New-CompactAction $f "I've checked in" 'Stops only check-in reminders for this school day. Commit/break and checkout reminders can still appear.' 14 48 274 { Set-CheckedIn }
    $checkedOutButton = New-CompactAction $f "I've checked out" 'Marks today complete and stops check-in, commit/break and checkout reminders until the next school day.' 302 48 274 { Set-CheckedOut }

    $schoolLoginButton = New-CompactAction $f 'Open school login' 'Opens your configured school login. Saved credentials are only used on the selected trusted HvA/UvA ADFS login when autofill is enabled.' 14 90 562 { Open-Link $script:config.loginUrl }

    $project1Button = New-CompactAction $f ([string]$script:config.option1Name) 'Opens your first configured project/check-in link. Opening it does not automatically mark you as checked in.' 14 132 274 {
        $url = $script:config.option1Url
        if ([string]::IsNullOrWhiteSpace($url)) { $url = $script:config.checkinUrl }
        Open-Link $url
    }
    $project2Button = New-CompactAction $f ([string]$script:config.option2Name) 'Opens your second configured project/check-in link. Its name and URL can be changed in Settings.' 302 132 274 {
        $url = $script:config.option2Url
        if ([string]::IsNullOrWhiteSpace($url)) { $url = $script:config.checkinUrl }
        Open-Link $url
    }

    $notNowButton = New-CompactAction $f 'Not now - 15 min' 'Closes this popup temporarily. Your status does not change and CampusBoop can remind you again later.' 14 174 274 {
        $script:nextReminder = (Get-Date).AddMinutes(15); $script:dialog.Close()
    }
    $settingsButton = New-CompactAction $f 'Settings' 'Change reminders, startup behavior, school links, student tools, schedule and optional trusted login autofill.' 302 174 274 { Show-Settings }

    $toolsLabel = New-Object Windows.Forms.Label
    $toolsLabel.Text = 'Student tools'
    $toolsLabel.Font = New-Object Drawing.Font('Segoe UI',8.5,[Drawing.FontStyle]::Bold)
    $toolsLabel.Location = New-Object Drawing.Point(14,219); $toolsLabel.Size = New-Object Drawing.Size(562,20)
    $toolsLabel.Anchor = 'Top,Left,Right'; $f.Controls.Add($toolsLabel)

    $tool1Button = New-CompactAction $f ([string]$script:config.tool1Name) 'Opens your configured print portal. The name and URL are editable in Settings.' 14 245 180 { Open-Link $script:config.tool1Url $true }
    $tool2Button = New-CompactAction $f ([string]$script:config.tool2Name) 'Opens your configured card/print-balance top-up page. CampusBoop never processes the payment itself.' 204 245 180 { Open-Link $script:config.tool2Url $true }
    $tool3Button = New-CompactAction $f ([string]$script:config.tool3Name) 'Opens your configured library page. The name and URL are editable in Settings.' 394 245 180 { Open-Link $script:config.tool3Url $true }

    $hint = New-Object Windows.Forms.Label
    $hint.Text = [char]0x24D8 + ' Hover or click an info icon for details.'
    $hint.ForeColor = [Drawing.ColorTranslator]::FromHtml('#5F5874')
    $hint.Location = New-Object Drawing.Point(14,289); $hint.Size = New-Object Drawing.Size(562,22)
    $hint.Anchor = 'Top,Left,Right'; $f.Controls.Add($hint)

    # Keep the action grid balanced when the user resizes the window.
    $layoutMain = {
        $margin = 14; $gap = 14
        $usable = [Math]::Max(500,($f.ClientSize.Width - ($margin * 2)))
        $half = [int](($usable - $gap) / 2)
        $right = $margin + $half + $gap
        foreach ($pair in @(@($checkedInButton,$margin),@($project1Button,$margin),@($notNowButton,$margin),@($checkedOutButton,$right),@($project2Button,$right),@($settingsButton,$right))) {
            $b=$pair[0]; $x=[int]$pair[1]; $b.Left=$x; $b.Width=[Math]::Max(90,($half - 30)); if ($b.Tag) { $b.Tag.Left=$x+$half-28 }
        }
        $schoolLoginButton.Left=$margin; $schoolLoginButton.Width=[Math]::Max(160,($usable - 30)); if ($schoolLoginButton.Tag) { $schoolLoginButton.Tag.Left=$margin+$usable-28 }

        $toolGap = 10; $toolCell = [int](($usable - ($toolGap * 2)) / 3)
        $toolX = $margin
        foreach ($b in @($tool1Button,$tool2Button,$tool3Button)) {
            $b.Left=$toolX; $b.Width=[Math]::Max(70,($toolCell - 30)); if ($b.Tag) { $b.Tag.Left=$toolX+$toolCell-28 }
            $toolX += $toolCell + $toolGap
        }
        $status.Width=[Math]::Max(200,($f.ClientSize.Width-28)); $toolsLabel.Width=$status.Width; $hint.Width=$status.Width
    }.GetNewClosure()
    $f.Add_SizeChanged($layoutMain)
    & $layoutMain

    $f.Add_FormClosed({
        $script:dialog = $null
        if ($script:nextReminder -lt (Get-Date)) { $script:nextReminder = (Get-Date).AddMinutes([int]$script:config.cooldownMinutes) }
        if (-not $script:config.backgroundEnabled) { [Windows.Forms.Application]::ExitThread() }
    })
    Show-Centered $f
}
function Get-ScheduledCheckoutTime([datetime]$now) {
    if (-not [bool]$script:config.scheduleEnabled) { return $null }
    $todayName = $now.DayOfWeek.ToString()
    foreach ($rule in $script:config.weeklySchedule) {
        if (-not [bool]$rule.enabled -or [string]$rule.day -ne $todayName) { continue }
        $startTime = [datetime]::MinValue; $endTime = [datetime]::MinValue
        $startOk = [datetime]::TryParseExact([string]$rule.start,'HH:mm',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$startTime)
        $endOk = [datetime]::TryParseExact([string]$rule.end,'HH:mm',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$endTime)
        if (-not $startOk -or -not $endOk) { continue }
        $target = $now.Date.AddHours($endTime.Hour).AddMinutes($endTime.Minute)
        $startMinute = $startTime.Hour * 60 + $startTime.Minute
        $endMinute = $endTime.Hour * 60 + $endTime.Minute
        if ($endMinute -le $startMinute) { $target = $target.AddDays(1) }
        return $target
    }
    return $null
}

function Test-CheckoutReminderDue([datetime]$now) {
    if (-not [bool]$script:config.checkoutReminderEnabled) { return $false }
    if ((Get-TodayState) -ne 'checkedin') { return $false }
    $day = Get-CampusDay $now
    if ($script:checkoutReminderDay -eq $day) { return $false }
    $target = Get-ScheduledCheckoutTime $now
    if ($null -eq $target) { return $false }
    $lead = [Math]::Max(0,[Math]::Min(180,[int]$script:config.checkoutLeadMinutes))
    return ($now -ge $target.AddMinutes(-$lead) -and $now -le $target.AddMinutes(60))
}

$script:tray = New-Object System.Windows.Forms.NotifyIcon
$script:tray.Icon = New-Object Drawing.Icon((Join-Path $PSScriptRoot 'assets\creatorpromote.ico'))
$script:tray.Text = 'CampusBoop'; $script:tray.Visible = $true
$menu = New-Object System.Windows.Forms.ContextMenuStrip
function Add-Menu([string]$name, $action) { $item = $menu.Items.Add($name); $item.Add_Click($action); return $item }
$null = Add-Menu 'Open CampusBoop' { Show-Checkin }
$null = Add-Menu "I've checked in" { Set-CheckedIn }
$null = Add-Menu "I've checked out - finish today" { Set-CheckedOut }
$null = Add-Menu 'Boop: commit and break reminder' { Show-CommitReminder }
$null = Add-Menu 'Settings / personal preferences' { Show-Settings }
$pauseItem = Add-Menu 'Pause reminders' { $script:paused = -not $script:paused; $pauseItem.Checked = $script:paused }
$null = Add-Menu 'Take a 10-minute break' { Start-Break }
$null = Add-Menu 'Resume work' { Resume-Work }
$null = Add-Menu 'Exit' { [Windows.Forms.Application]::ExitThread() }
$script:tray.ContextMenuStrip = $menu
$script:tray.Add_DoubleClick({ Show-Checkin })
$script:tray.Add_BalloonTipClicked({
    if ($script:lastNotification -eq 'commit') { Show-CommitReminder }
    elseif ($script:lastNotification -eq 'checkout') { Show-Checkout }
    else { Show-Checkin }
})

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 2000
$timer.Add_Tick({
    $now = Get-Date
    $today = Get-CampusDay $now
    $state = Get-TodayState
    $request = Join-Path $script:dataDir 'open-request'
    if (Test-Path -LiteralPath $request) { Remove-Item -LiteralPath $request; Show-Checkin }

    # Startup reminder: intentionally independent of the weekly schedule. If enabled,
    # every Windows sign-in can show one check-in reminder after the selected delay,
    # unless this school day is already checked in/out or reminders are paused.
    if (-not $script:startupReminderShown -and [bool]$script:config.startupReminderEnabled -and $now -ge $script:startupReminderAt) {
        $script:startupReminderShown = $true
        if (-not $script:paused -and $state -eq 'notcheckedin') {
            $script:lastNotification = 'startup'
            Show-Checkin
            return
        }
    }

    $codeWindows = @(Get-Process -Name 'Code','Code - Insiders' -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 })
    $hasCodeWindow = $codeWindows.Count -gt 0
    $codeJustClosed = $script:hadCodeWindow -and -not $hasCodeWindow
    $script:hadCodeWindow = $hasCodeWindow

    if ($script:paused -or $state -eq 'checkedout') { return }
    if ($now -lt $script:breakUntil) { return }

    # If a scheduled school day is ending and the student is checked in, remind them to check out.
    if (Test-CheckoutReminderDue $now) {
        $script:checkoutReminderDay = $today
        $script:lastNotification = 'checkout'
        Show-Checkout
        return
    }

    # Closing VS Code while checked in is another useful checkout signal.
    if ($codeJustClosed -and $state -eq 'checkedin') {
        $script:lastNotification = 'checkout'
        Show-Checkout
        return
    }

    if (-not $hasCodeWindow) { return }
    if (-not (Test-AlarmTime $now)) { return }

    [uint32]$foregroundPid = 0
    $null = [SchoolWindow]::GetWindowThreadProcessId([SchoolWindow]::GetForegroundWindow(), [ref]$foregroundPid)
    if ($foregroundPid -eq 0) { return }
    $process = Get-Process -Id $foregroundPid -ErrorAction SilentlyContinue
    if (-not $process -or $process.ProcessName -notin @('Code','Code - Insiders')) { return }

    if ($script:commitDialog -and -not $script:commitDialog.IsDisposed) { return }
    if ($script:dialog -and -not $script:dialog.IsDisposed) { return }
    if ($script:checkoutDialog -and -not $script:checkoutDialog.IsDisposed) { return }

    if ($state -eq 'notcheckedin') {
        if ([bool]$script:config.smartReminderEnabled -and $now -ge $script:nextReminder) {
            $script:nextReminder = $now.AddMinutes([int]$script:config.cooldownMinutes)
            $script:lastNotification = 'checkin'
            Show-Checkin
        }
        return
    }

    if ($state -eq 'checkedin' -and $now -ge $script:nextCommitReminder) {
        $script:nextCommitReminder = $now.AddMinutes([int]$script:config.reminderMinutes)
        $script:lastNotification = 'commit'
        Show-CommitReminder
    }
})

try {
    if (-not $script:config.onboardingComplete) {
        if (-not (Show-FirstRun)) { return }
    }
    if (Test-StartupEnabled) { Set-StartupEnabled $true }
    Save-Config
    $timer.Start()
    if (-not $Background -or -not $script:config.backgroundEnabled) { Show-Checkin }
    [Windows.Forms.Application]::Run()
} finally {
    $timer.Stop(); $timer.Dispose(); $script:tray.Visible = $false; $script:tray.Dispose()
    $mutex.ReleaseMutex(); $mutex.Dispose()
}
